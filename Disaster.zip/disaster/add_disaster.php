<?php
session_start();
include('db.php');

// Check admin access
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $place = $_POST['place'];
    $severity = $_POST['severity'];
    $year = $_POST['year'];
    $duration = $_POST['duration'];

    // Prepare and execute the insert query
    $stmt = $conn->prepare("INSERT INTO disasters (name, place, severity, year, duration) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssii", $name, $place, $severity, $year, $duration);

    if ($stmt->execute()) {
        header("Location: view_disasters.php?success=" . urlencode($name));
        exit();
    } else {
        $error_message = "Error adding disaster. (Possibly duplicate name)";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Disaster</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php include 'header.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4 text-center">Add Disaster</h2>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?= $error_message ?></div>
    <?php endif; ?>

    <form action="" method="POST" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Disaster Name</label>
            <input type="text" class="form-control" name="name" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Place</label>
            <input type="text" class="form-control" name="place" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Severity</label>
            <select class="form-control" name="severity" required>
                <option value="">Select Severity</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Year</label>
            <input type="number" class="form-control" name="year" min="1900" max="2100" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Duration (days)</label>
            <input type="number" class="form-control" name="duration" min="1" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Add Disaster</button>
    </form>

    <div class="text-center mt-3">
        <a href="view_disasters.php" class="btn btn-secondary btn-sm">Back to Disasters</a>
        <a href="admin_dashboard.php" class="btn btn-secondary btn-sm">Back to Dashboard</a>
    </div>
</div>

</body>
</html>
