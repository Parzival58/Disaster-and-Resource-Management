<?php
session_start();
include '../config.php';

// check admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// variable
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name        = trim($_POST['name']);
    $type        = trim($_POST['type']);
    $description = trim($_POST['description']);
    $severity    = trim($_POST['severity']);
    $date        = trim($_POST['date']);
    $location    = trim($_POST['location']);


    if (!empty($name) && !empty($type) && !empty($description) && !empty($severity) && !empty($date) && !empty($location)) {
        $stmt = $conn->prepare("INSERT INTO disaster_information (name, type, description, severity, date, location) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $type, $description, $severity, $date, $location);

        if ($stmt->execute()) {
            $success = "✅ Disaster information added successfully.";
        } else {
            $error = "❌ Error: Could not add information. " . $stmt->error;
        }
        $stmt->close();
    } else {
        $error = "❌ Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Disaster Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('navbar.php'); ?>

    <div class="container mt-5">
        <h2 class="mb-4">🌪️ Add Disaster Information</h2>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="post" class="card p-4 shadow-sm mb-4">
            <div class="mb-3">
                <label for="name" class="form-label"><strong>Disaster Name:</strong></label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="type" class="form-label"><strong>Disaster Type:</strong></label>
                <input type="text" name="type" id="type" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label"><strong>Description:</strong></label>
                <textarea name="description" id="description" class="form-control" rows="5" required></textarea>
            </div>

            <div class="mb-3">
                <label for="severity" class="form-label"><strong>Severity:</strong></label>
                <select name="severity" id="severity" class="form-select" required>
                    <option value="">Select severity</option>
                    <option value="Low">Low</option>
                    <option value="Moderate">Moderate</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="date" class="form-label"><strong>Date Occurred:</strong></label>
                <input type="date" name="date" id="date" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="location" class="form-label"><strong>Location:</strong></label>
                <input type="text" name="location" id="location" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary">Add Disaster</button>
        </form>

        <a href="view_disasters.php" class="btn btn-secondary">View Disasters</a>
        <a href="admin_dashboard.php" class="btn btn-light ms-2">← Back to Dashboard</a>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
