<?php
session_start();
include("../config.php");

// admin check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// shelter's info
$shelters = [];
$result = $conn->query("SELECT id, name FROM shelter_information ORDER BY name ASC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $shelters[] = $row;
    }
}

// variables
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $type = trim($_POST['type']);
    $quantity = intval($_POST['quantity']);
    $shelter_id = intval($_POST['shelter_id']);

    $stmt = $conn->prepare("INSERT INTO resources (name, type, quantity, shelter_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssii", $name, $type, $quantity, $shelter_id);

    if ($stmt->execute()) {
        header("Location: resources_view.php");
        exit();
    } else {
        $error = "Failed to add resource: " . $conn->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Resource</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">➕ Add New Resource</h2>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="name" class="form-label">Resource Name</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="type" class="form-label">Resource Type</label>
            <input type="text" name="type" id="type" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="quantity" class="form-label">Quantity</label>
            <input type="number" name="quantity" id="quantity" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="shelter_id" class="form-label">Shelter</label>
            <select name="shelter_id" id="shelter_id" class="form-select" required>
                <option value="" selected disabled>-- Select Shelter --</option>
                <?php foreach ($shelters as $shelter): ?>
                    <option value="<?= $shelter['id'] ?>"><?= htmlspecialchars($shelter['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Save Resource</button>
        <a href="resources_view.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
