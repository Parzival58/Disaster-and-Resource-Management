<?php
session_start();
include '../config.php';

// check admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// variable
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name              = trim($_POST['name']);
    $capacity          = trim($_POST['capacity']);
    $current_occupancy = trim($_POST['current_occupancy']);
    $location          = trim($_POST['location']);
    $contact_number    = trim($_POST['contact_number']);

    if (!empty($name) && !empty($capacity) && !empty($current_occupancy) && !empty($location) && !empty($contact_number)) {
        $stmt = $conn->prepare("INSERT INTO shelter_information (name, capacity, current_occupancy, location, contact_number) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $capacity, $current_occupancy, $location, $contact_number);

        if ($stmt->execute()) {
            $success = "✅ Shelter added successfully.";
        } else {
            $error = "❌ Error: Could not add shelter. " . $stmt->error;
        }
        $stmt->close();
    } else {
        $error = "❌ Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Shelter</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">


    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">🏠 Add Shelter</h2>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" class="card p-4 shadow-sm mb-4">
        <div class="mb-3">
            <label for="name" class="form-label"><strong>Shelter Name:</strong></label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="capacity" class="form-label"><strong>Capacity:</strong></label>
            <input type="number" name="capacity" id="capacity" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="current_occupancy" class="form-label"><strong>Current Occupancy:</strong></label>
            <input type="number" name="current_occupancy" id="current_occupancy" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="location" class="form-label"><strong>Location:</strong></label>
            <input type="text" name="location" id="location" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="contact_number" class="form-label"><strong>Contact Number:</strong></label>
            <input type="text" name="contact_number" id="contact_number" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Add Shelter</button>
        <a href="view_shelters.php" class="btn btn-secondary ms-2">← Back to View Shelters</a>
    </form>
</div>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
