<?php
session_start();
include '../config.php';

// Redirect if admin is not logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Add user on form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name        = $_POST['name'];
    $username    = $_POST['username'];
    $email       = $_POST['email'];
    $phone       = $_POST['phone'];
    $address     = $_POST['address'];
    $blood_group = $_POST['blood_group'];
    $role        = $_POST['role'];

    // Validate form data
    if (empty($name) || empty($username) || empty($email) || empty($role)) {
        echo "Please fill in all required fields!";
        exit();
    }

    // Prepare and bind query for inserting new user into the database
    $stmt = $conn->prepare("INSERT INTO users (name, username, email, phone, address, blood_group, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $username, $email, $phone, $address, $blood_group, $role);

    // Execute the statement and check if insertion was successful
    if ($stmt->execute()) {
        header("Location: manage_users.php");
        exit();
    } else {
        echo "Error adding user: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New User</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('navbar.php'); ?>

    <div class="container mt-5">
        <h2 class="mb-4">Add New User</h2>

        <form method="post" class="card p-4 shadow">
            <div class="row">
                <div class="mb-3 col-md-6">
                    <label class="form-label">Name:</label>
                    <input type="text" class="form-control" name="name" required>
                </div>

                <div class="mb-3 col-md-6">
                    <label class="form-label">Username:</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
            </div>

            <div class="row">
                <div class="mb-3 col-md-6">
                    <label class="form-label">Email:</label>
                    <input type="email" class="form-control" name="email" required>
                </div>

                <div class="mb-3 col-md-6">
                    <label class="form-label">Phone:</label>
                    <input type="text" class="form-control" name="phone">
                </div>
            </div>

            <div class="row">
                <div class="mb-3 col-md-6">
                    <label class="form-label">Address:</label>
                    <input type="text" class="form-control" name="address">
                </div>

                <div class="mb-3 col-md-3">
                    <label class="form-label">Blood Group:</label>
                    <select class="form-select" name="blood_group" required>
                        <option value="">Select</option>
                        <?php
                        $groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
                        foreach ($groups as $group) {
                            echo "<option value='$group'>$group</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3 col-md-3">
                    <label class="form-label">Role:</label>
                    <select class="form-select" name="role" required>
                        <option value="">Select Role</option>
                        <?php
                        $roles = ['admin', 'user'];
                        foreach ($roles as $r) {
                            echo "<option value='$r'>$r</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Add User</button>
                <a href="manage_users.php" class="btn btn-secondary ms-2">Back to Manage Users</a>
            </div>
        </form>
    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
