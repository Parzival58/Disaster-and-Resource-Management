<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include("../config.php");

// Restrict to admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Count queries
$userQuery = "SELECT COUNT(*) AS total_users FROM `users`";
$totalUsers = $conn->query($userQuery)->fetch_assoc()['total_users'] ?? 0;

$disasterQuery = "SELECT COUNT(*) AS total_disasters FROM `disaster_information`";
$totalDisasters = $conn->query($disasterQuery)->fetch_assoc()['total_disasters'] ?? 0;

$shelterQuery = "SELECT COUNT(*) AS total_shelters FROM `shelter_information`";
$totalShelters = $conn->query($shelterQuery)->fetch_assoc()['total_shelters'] ?? 0;

$ambulanceQuery = "SELECT COUNT(*) AS total_ambulances FROM `ambulance`";
$totalAmbulances = $conn->query($ambulanceQuery)->fetch_assoc()['total_ambulances'] ?? 0;

$fireQuery = "SELECT COUNT(*) AS total_fire_stations FROM `fire_service`";
$totalFireStations = $conn->query($fireQuery)->fetch_assoc()['total_fire_stations'] ?? 0;

$hospitalQuery = "SELECT COUNT(*) AS total_hospitals FROM `hospital`";
$totalHospitals = $conn->query($hospitalQuery)->fetch_assoc()['total_hospitals'] ?? 0;

$policeQuery = "SELECT COUNT(*) AS total_police_stations FROM `police`";
$totalPoliceStations = $conn->query($policeQuery)->fetch_assoc()['total_police_stations'] ?? 0;

$resourceQuery = "SELECT COUNT(*) AS total_resources FROM `resources`";
$totalResources = $conn->query($resourceQuery)->fetch_assoc()['total_resources'] ?? 0;

$volunteerQuery = "SELECT COUNT(*) AS pending_requests FROM `volunteer_requests` WHERE status='pending'";
$pendingVolunteerRequests = $conn->query($volunteerQuery)->fetch_assoc()['pending_requests'] ?? 0;

$checkinQuery = "SELECT COUNT(*) AS total_checkedin FROM shelter_checkins WHERE checkout_time IS NULL";
$totalCheckedIn = $conn->query($checkinQuery)->fetch_assoc()['total_checkedin'] ?? 0;

// Count total SOS requests
$sosQuery = "SELECT COUNT(*) AS total_sos FROM `sos`";
$totalSOS = $conn->query($sosQuery)->fetch_assoc()['total_sos'] ?? 0;
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .notification-badge {
            position: absolute;
            top: 10px;
            right: 15px;
            padding: 5px 8px;
            border-radius: 50%;
            background: red;
            color: white;
            font-size: 0.75rem;
        }
    </style>
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <div class="card shadow p-4">
        <h2 class="mb-3">Welcome, <?= htmlspecialchars($_SESSION['username']); ?>!</h2>
        <p class="mb-4">This is the admin dashboard.</p>

        <div class="row row-cols-1 row-cols-md-3 g-4">

            <div class="col">
                <a href="manage_users.php" class="text-decoration-none">
                    <div class="card text-white bg-primary h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Total Users</h5>
                                <i class="fa-solid fa-users fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalUsers ?></p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="view_disasters.php" class="text-decoration-none">
                    <div class="card text-white bg-success h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Total Disaster Information</h5>
                                <i class="fa-solid fa-triangle-exclamation fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalDisasters ?></p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="view_shelters.php" class="text-decoration-none">
                    <div class="card text-white bg-info h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Total Shelters</h5>
                                <i class="fa-solid fa-house-chimney fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalShelters ?></p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="ambulance_view.php" class="text-decoration-none">
                    <div class="card text-white bg-warning h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Total Ambulances</h5>
                                <i class="fa-solid fa-truck-medical fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalAmbulances ?></p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="fire_view.php" class="text-decoration-none">
                    <div class="card text-white bg-dark h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Total Fire Stations</h5>
                                <i class="fa-solid fa-fire-extinguisher fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalFireStations ?></p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="hospital_view.php" class="text-decoration-none">
                    <div class="card text-white bg-secondary h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Total Hospitals</h5>
                                <i class="fa-solid fa-hospital fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalHospitals ?></p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="police_view.php" class="text-decoration-none">
                    <div class="card text-white bg-danger h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Total Police Stations</h5>
                                <i class="fa-solid fa-shield-halved fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalPoliceStations ?></p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="view_resources.php" class="text-decoration-none">
                    <div class="card text-white h-100" style="background-color: #20c997;">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Total Resources</h5>
                                <i class="fa-solid fa-boxes-stacked fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalResources ?></p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="manage_volunteers.php" class="text-decoration-none position-relative">
                    <div class="card text-white h-100" style="background-color: #6f42c1;">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Pending Volunteer Requests</h5>
                                <i class="fa-solid fa-handshake-angle fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $pendingVolunteerRequests ?></p>
                        </div>
                    </div>
                    <?php if ($pendingVolunteerRequests > 0): ?>
                        <span class="notification-badge"><?= $pendingVolunteerRequests ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <!-- ✅ SOS Management Card -->
            <div class="col">
                <a href="sos_view.php" class="text-decoration-none">
                    <div class="card text-white bg-danger h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Manage SOS Requests</h5>
                                <i class="fa-solid fa-bell fa-2x"></i>
                            </div>
                            <p class="card-text fs-3"><?= $totalSOS ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <!-- ✅ Contact Messages Card -->
            <div class="col">
                <a href="contact_messages.php" class="text-decoration-none">
                    <div class="card text-white bg-primary h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="card-title">Contact Messages</h5>
                                <i class="fa-solid fa-envelope fa-2x"></i>
                            </div>
                            <p class="card-text fs-3">
                                <?php
                                $contactQuery = "SELECT COUNT(*) AS total_contacts FROM contact_us";
                                $totalContacts = $conn->query($contactQuery)->fetch_assoc()['total_contacts'] ?? 0;
                                echo $totalContacts;
                                ?>
                            </p>
                        </div>
                    </div>
                </a>
            </div>

                <div class="col">
                    <a href="checkedin_users.php" class="text-decoration-none">
                        <div class="card text-white" style="background-color: #17a2b8;">
                            <div class="card-body">
                                <div class="d-flex align-items-center justify-content-between">
                                    <h5 class="card-title">Checked-in Users</h5>
                                    <i class="fa-solid fa-person-shelter fa-2x"></i>
                                </div>
                                <p class="card-text fs-3"><?= $totalCheckedIn ?></p>
                            </div>
                        </div>
                    </a>
                </div>

        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
