<?php
session_start();
include('config.php');

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$requests = $conn->query("
    SELECT rr.*, u.name AS user_name, r.name AS resource_name, si.name AS shelter_name
    FROM resource_request rr
    JOIN users u ON rr.requested_by_user_id = u.id
    JOIN resources r ON rr.resource_name = r.name
    JOIN shelter_information si ON rr.shelter_id = si.id
    WHERE rr.status = 'pending'
    ORDER BY rr.request_date DESC
");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Resource Requests</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-4">
    <h2>Admin - Resource Requests</h2>
    <div class="content-box">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Resource</th>
                    <th>Requested Quantity</th>
                    <th>Shelter</th>
                    <th>Request Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $requests->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['user_name']) ?></td>
                        <td><?= htmlspecialchars($row['resource_name']) ?></td>
                        <td><?= htmlspecialchars($row['requested_quantity']) ?></td>
                        <td><?= htmlspecialchars($row['shelter_name']) ?></td>
                        <td><?= htmlspecialchars($row['request_date']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td>
                            <!-- Only allow allocation if the request is pending -->
                            <?php if ($row['status'] == 'pending'): ?>
                                <form action="allocate_resource.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                                    <input type="hidden" name="resource_name" value="<?= $row['resource_name'] ?>">
                                    <input type="hidden" name="requested_quantity" value="<?= $row['requested_quantity'] ?>">
                                    <button class="btn btn-outline-success" name="action" value="allocate">Allocate</button>
                                    <button class="btn btn-outline-danger" name="action" value="reject">Reject</button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted">Action taken</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
