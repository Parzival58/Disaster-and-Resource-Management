<?php
session_start();
include('config.php');

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the form
    $request_id = $_POST['request_id'];
    $resource_name = $_POST['resource_name'];
    $requested_quantity = $_POST['requested_quantity'];
    $action = $_POST['action'];

    if (empty($request_id) || empty($resource_name) || empty($requested_quantity) || empty($action)) {
        $_SESSION['message'] = 'All fields are required!';
        header("Location: resource_requests.php");
        exit();
    }

    // Check if the requested quantity is valid
    if (!is_numeric($requested_quantity) || $requested_quantity <= 0) {
        $_SESSION['message'] = 'Requested quantity must be a positive number.';
        header("Location: resource_requests.php");
        exit();
    }

    // Start a transaction to ensure atomicity
    $conn->begin_transaction();

    try {
        if ($action == 'allocate') {
            // Check if the resource has enough quantity
            $resourceQuery = "SELECT quantity FROM resources WHERE name = ?";
            $stmt = $conn->prepare($resourceQuery);
            $stmt->bind_param("s", $resource_name);
            $stmt->execute();
            $stmt->bind_result($available_quantity);
            $stmt->fetch();
            $stmt->close();

            if ($available_quantity < $requested_quantity) {
                $_SESSION['message'] = 'Not enough resources available to allocate.';
                header("Location: resource_requests.php");
                exit();
            }

            // Update the status of the request to "allocated"
            $updateRequestQuery = "UPDATE resource_request SET status = 'allocated' WHERE id = ?";
            $stmt = $conn->prepare($updateRequestQuery);
            $stmt->bind_param("i", $request_id);
            $stmt->execute();
            $stmt->close();

            // Reduce the available resource quantity
            $updateResourceQuery = "UPDATE resources SET quantity = quantity - ? WHERE name = ?";
            $stmt = $conn->prepare($updateResourceQuery);
            $stmt->bind_param("is", $requested_quantity, $resource_name);
            $stmt->execute();
            $stmt->close();

            $_SESSION['message'] = 'Resource allocated successfully.';
        } elseif ($action == 'reject') {
            // Update the status of the request to "rejected"
            $updateRequestQuery = "UPDATE resource_request SET status = 'rejected' WHERE id = ?";
            $stmt = $conn->prepare($updateRequestQuery);
            $stmt->bind_param("i", $request_id);
            $stmt->execute();
            $stmt->close();

            $_SESSION['message'] = 'Resource request rejected.';
        } else {
            throw new Exception('Invalid action.');
        }

        // Commit the transaction
        $conn->commit();
    } catch (Exception $e) {
        // Rollback the transaction if any error occurs
        $conn->rollback();
        $_SESSION['message'] = 'An error occurred: ' . $e->getMessage();
    }

    // Redirect to the resource requests page
    header("Location: resource_requests.php");
    exit();
}
?>
