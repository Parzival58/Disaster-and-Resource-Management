<?php
session_start();
include '../config.php';

// Restrict to admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Handle form submission
$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $driver = trim($_POST['driver']);
    $driver_phone_number = trim($_POST['driver_phone_number']);
    $location = trim($_POST['location']);
    $registration_number = trim($_POST['registration_number']);

    $stmt = $conn->prepare("INSERT INTO ambulance (driver, driver_phone_number, location, registration_number) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $driver, $driver_phone_number, $location, $registration_number);

    if ($stmt->execute()) {
        $success = "✅ Ambulance added successfully.";
    } else {
        $error = "❌ Failed to add ambulance. Please try again.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Ambulance</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">🚑 Add Ambulance</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label for="driver" class="form-label">Driver</label>
            <input type="text" class="form-control" id="driver" name="driver" required>
        </div>
        <div class="mb-3">
            <label for="driver_phone_number" class="form-label">Driver Phone Number</label>
            <input type="text" class="form-control" id="driver_phone_number" name="driver_phone_number" required>
        </div>
        <div class="mb-3">
            <label for="location" class="form-label">Location</label>
            <input type="text" class="form-control" id="location" name="location" required>
        </div>
        <div class="mb-3">
            <label for="registration_number" class="form-label">Registration Number</label>
            <input type="text" class="form-control" id="registration_number" name="registration_number" required>
        </div>
        <button type="submit" class="btn btn-primary">➕ Add Ambulance</button>
        <a href="view_ambulances.php" class="btn btn-secondary ms-2">← Back to Ambulances</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
