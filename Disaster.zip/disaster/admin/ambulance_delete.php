<?php
include 'db_connect.php';
$id = $_GET['id'];
$conn->query("DELETE FROM ambulance WHERE id = $id");
header("Location: ambulance_view.php");
?>
