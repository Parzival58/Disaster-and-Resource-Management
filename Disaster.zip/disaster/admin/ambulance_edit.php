<?php
session_start();
include '../config.php';

// Restrict to admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Validate and fetch ambulance by ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: view_ambulances.php");
    exit();
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM ambulance WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$ambulance = $result->fetch_assoc();

if (!$ambulance) {
    header("Location: view_ambulances.php");
    exit();
}

// Handle form submission
$success = $error = '';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $driver = trim($_POST['driver']);
    $driver_phone = trim($_POST['driver_phone_number']);
    $reg_number = trim($_POST['registration_number']);
    $location = trim($_POST['location']);

    $updateStmt = $conn->prepare("UPDATE ambulance SET driver = ?, driver_phone_number = ?, registration_number = ?, location = ? WHERE id = ?");
    $updateStmt->bind_param("ssssi", $driver, $driver_phone, $reg_number, $location, $id);

    if ($updateStmt->execute()) {
        $success = "✅ Ambulance information updated successfully.";
        // Refresh the data
        $stmt = $conn->prepare("SELECT * FROM ambulance WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $ambulance = $result->fetch_assoc();
    } else {
        $error = "❌ Failed to update ambulance information.";
    }
    $updateStmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Ambulance</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">✏️ Edit Ambulance Information</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Driver Name</label>
            <input type="text" class="form-control" name="driver" value="<?= htmlspecialchars($ambulance['driver']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Driver Phone Number</label>
            <input type="text" class="form-control" name="driver_phone_number" value="<?= htmlspecialchars($ambulance['driver_phone_number']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Registration Number</label>
            <input type="text" class="form-control" name="registration_number" value="<?= htmlspecialchars($ambulance['registration_number']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" class="form-control" name="location" value="<?= htmlspecialchars($ambulance['location']) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Ambulance</button>
        <a href="view_ambulances.php" class="btn btn-secondary ms-2">← Back to Ambulances</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
