<?php
session_start();
include 'config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access denied.");
}

$query = "SELECT sc.id, u.name, u.phone, u.blood_group, s.name AS shelter_name, s.location, sc.checkin_time
          FROM shelter_checkins sc
          JOIN users u ON sc.user_id = u.id
          JOIN shelter_information s ON sc.shelter_id = s.id
          WHERE sc.checkout_time IS NULL
          ORDER BY sc.checkin_time DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Checked-In Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>📋 Currently Checked-In Users</h2>
        <a href="admin_dashboard.php" class="btn btn-secondary mb-3 ms-2">← Back to Home</a>
    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>Serial</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Blood Group</th>
                <th>Shelter</th>
                <th>Location</th>
                <th>Check-in Time</th>
            </tr>
        </thead>
        <tbody>
        <?php $i = 1; while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['phone']) ?></td>
                <td><?= htmlspecialchars($row['blood_group']) ?></td>
                <td><?= htmlspecialchars($row['shelter_name']) ?></td>
                <td><?= htmlspecialchars($row['location']) ?></td>
                <td><?= $row['checkin_time'] ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
