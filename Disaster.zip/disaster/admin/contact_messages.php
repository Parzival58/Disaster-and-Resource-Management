<?php
session_start();
include('config.php');

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access denied.");
}

// Fetch all contact messages
$query = "SELECT c.id, c.user_id, c.name, c.email, c.problem_type, c.message, c.submitted_at, c.reply, c.admin_reply_date, u.username
          FROM contact_us c
          LEFT JOIN users u ON c.user_id = u.id
          ORDER BY c.submitted_at DESC";
$messages_result = $conn->query($query);

// Handle reply submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reply_message'], $_POST['message_id'])) {
    $reply_message = $_POST['reply_message'];
    $message_id = (int) $_POST['message_id'];

    if (!empty($reply_message)) {
        // Insert reply into the contact_us table
        $stmt = $conn->prepare("UPDATE contact_us SET reply = ?, admin_reply_date = NOW() WHERE id = ?");
        $stmt->bind_param("si", $reply_message, $message_id);
        if ($stmt->execute()) {
            $success = "✅ Your reply has been sent successfully!";
        } else {
            $error = "❌ Failed to send your reply. Please try again.";
        }
        $stmt->close();
    } else {
        $error = "❌ Please provide a reply before submitting.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Contact Us Messages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">📬 Contact Us Messages</h2>
    <a href="admin_dashboard.php" class="btn btn-secondary mb-3 ms-2">← Back to Home</a>
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Messages Table -->
    <?php if ($messages_result->num_rows > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Problem Type</th>
                        <th>Message</th>
                        <th>Admin Reply</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $messages_result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']) ?></td>
                            <td><?= htmlspecialchars($row['user_id']) ?></td>
                            <td><?= htmlspecialchars($row['name'] ?: $row['username']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td><?= htmlspecialchars($row['problem_type']) ?></td>
                            <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
                            <td>
                                <?php if ($row['reply']): ?>
                                    <p><strong>Reply:</strong> <?= nl2br(htmlspecialchars($row['reply'])) ?></p>
                                    <small class="text-muted">Replied on: <?= date('d M Y, h:i A', strtotime($row['admin_reply_date'])) ?></small>
                                <?php else: ?>
                                    <span class="text-muted">No reply yet</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!$row['reply']): ?>
                                    <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#replyModal<?= $row['id'] ?>">Reply</button>
                                <?php else: ?>
                                    <span class="badge bg-success">Replied</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info">📭 No contact messages yet.</div>
    <?php endif; ?>
</div>

<!-- Modal for Reply -->
<?php
// Reset result pointer
$messages_result->data_seek(0);
while ($row = $messages_result->fetch_assoc()):
?>
<div class="modal fade" id="replyModal<?= $row['id'] ?>" tabindex="-1" aria-labelledby="replyModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="replyModalLabel">Reply to Message (ID: <?= $row['id'] ?>)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="contact_messages.php">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="reply_message" class="form-label">Your Reply</label>
                        <textarea class="form-control" id="reply_message" name="reply_message" rows="4" required></textarea>
                    </div>
                    <input type="hidden" name="message_id" value="<?= $row['id'] ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Send Reply</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endwhile; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
