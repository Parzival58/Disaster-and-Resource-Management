$id = $_GET['id'];
$query = "DELETE FROM `resources` WHERE `id` = $id";
$conn->query($query);
header("Location: resources_view.php");
