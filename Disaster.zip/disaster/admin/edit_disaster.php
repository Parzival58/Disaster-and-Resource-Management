<?php
session_start();
include '../config.php';

// Ensure only logged-in admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get disaster info by ID
if (!isset($_GET['id'])) {
    header("Location: view_disasters.php");
    exit();
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM disaster_information WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$disaster = $result->fetch_assoc();

if (!$disaster) {
    header("Location: view_disasters.php");
    exit();
}

// Handle form update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name        = trim($_POST['name']);
    $type        = trim($_POST['type']);
    $description = trim($_POST['description']);
    $severity    = trim($_POST['severity']);
    $date        = trim($_POST['date']);
    $location    = trim($_POST['location']);

    // Validate all fields are filled
    if (!empty($name) && !empty($type) && !empty($description) && !empty($severity) && !empty($date) && !empty($location)) {
        $stmt = $conn->prepare("UPDATE disaster_information SET name=?, type=?, description=?, severity=?, date=?, location=? WHERE id=?");
        $stmt->bind_param("ssssssi", $name, $type, $description, $severity, $date, $location, $id);

        if ($stmt->execute()) {
            $success = "✅ Disaster information updated successfully.";
            // Refresh the data
            $stmt = $conn->prepare("SELECT * FROM disaster_information WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $disaster = $result->fetch_assoc();
        } else {
            $error = "❌ Error updating disaster information. " . $stmt->error;
        }
    } else {
        $error = "❌ Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Disaster Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">✏️ Edit Disaster Information</h2>

    <?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="post" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label"><strong>Disaster Name:</strong></label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($disaster['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>Disaster Type:</strong></label>
            <input type="text" name="type" class="form-control" value="<?= htmlspecialchars($disaster['type']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>Description:</strong></label>
            <textarea name="description" class="form-control" rows="5" required><?= htmlspecialchars($disaster['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>Severity:</strong></label>
            <select name="severity" class="form-select" required>
                <?php
                $severities = ['Low', 'Moderate', 'High', 'Critical'];
                foreach ($severities as $sev) {
                    $selected = ($disaster['severity'] == $sev) ? 'selected' : '';
                    echo "<option value='$sev' $selected>$sev</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>Date Occurred:</strong></label>
            <input type="date" name="date" class="form-control" value="<?= $disaster['date'] ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>Location:</strong></label>
            <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($disaster['location']) ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">💾 Update Disaster</button>
        <a href="view_disasters.php" class="btn btn-secondary ms-2">← Back to View Disasters</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
                