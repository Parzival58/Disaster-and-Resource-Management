<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include("../config.php");

// Restrict to admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Ensure resource ID is provided
if (!isset($_GET['id'])) {
    header("Location: resources_view.php");
    exit();
}

$resourceId = intval($_GET['id']);

// Fetch resource details
$query = "SELECT * FROM `resources` WHERE `id` = $resourceId";
$result = $conn->query($query);

if ($result->num_rows === 0) {
    echo "Resource not found.";
    exit();
}

$resource = $result->fetch_assoc();

// Fetch shelters for dropdown
$shelters = [];
$shelterResult = $conn->query("SELECT id, name FROM shelter_information");
if ($shelterResult && $shelterResult->num_rows > 0) {
    $shelters = $shelterResult->fetch_all(MYSQLI_ASSOC);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $type = $_POST['type'];
    $quantity = intval($_POST['quantity']);
    $shelter_id = intval($_POST['shelter_id']);

    $updateQuery = "UPDATE `resources` SET 
        `name` = '$name',
        `type` = '$type',
        `quantity` = $quantity,
        `shelter_id` = $shelter_id
        WHERE `id` = $resourceId";

    if ($conn->query($updateQuery) === TRUE) {
        header("Location: resources_view.php");
        exit();
    } else {
        echo "Error updating resource: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Resource</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-3">✏️ Edit Resource</h2>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="name" class="form-label">Resource Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($resource['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="type" class="form-label">Resource Type</label>
            <input type="text" class="form-control" id="type" name="type" value="<?= htmlspecialchars($resource['type']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="quantity" class="form-label">Quantity</label>
            <input type="number" class="form-control" id="quantity" name="quantity" value="<?= htmlspecialchars($resource['quantity']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="shelter_id" class="form-label">Shelter</label>
            <select name="shelter_id" id="shelter_id" class="form-select" required>
                <option value="">-- Select Shelter --</option>
                <?php foreach ($shelters as $shelter): ?>
                    <option value="<?= $shelter['id'] ?>" <?= $shelter['id'] == $resource['shelter_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($shelter['name']) ?> (ID: <?= $shelter['id'] ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Update Resource</button>
        <a href="view_resources.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
