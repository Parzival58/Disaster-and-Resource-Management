<?php
session_start();
include '../config.php';

// Ensure only logged-in admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get shelter info by ID
if (!isset($_GET['id'])) {
    header("Location: view_shelters.php");
    exit();
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM shelter_information WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$shelter = $result->fetch_assoc();

if (!$shelter) {
    header("Location: view_shelters.php");
    exit();
}

// Handle form update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name              = trim($_POST['name']);
    $capacity          = trim($_POST['capacity']);
    $current_occupancy = trim($_POST['current_occupancy']);
    $location          = trim($_POST['location']);
    $contact_email     = trim($_POST['contact_email']);
    $contact_phone     = trim($_POST['contact_phone']);
    $description       = trim($_POST['description']);

    // Update the shelter record
    $stmt = $conn->prepare("UPDATE shelter_information SET name=?, capacity=?, current_occupancy=?, location=?, contact_email=?, contact_phone=?, description=? WHERE id=?");
    $stmt->bind_param("sssssssi", $name, $capacity, $current_occupancy, $location, $contact_email, $contact_phone, $description, $id);

    if ($stmt->execute()) {
        $success = "✅ Shelter information updated successfully.";
        // Refresh the data
        $stmt = $conn->prepare("SELECT * FROM shelter_information WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $shelter = $result->fetch_assoc();
    } else {
        $error = "❌ Error updating shelter information.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Shelter Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Edit Shelter Information</h2>

    <?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="post" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Shelter Name:</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($shelter['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Capacity:</label>
            <input type="number" name="capacity" class="form-control" value="<?= $shelter['capacity'] ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Current Occupancy:</label>
            <input type="number" name="current_occupancy" class="form-control" value="<?= $shelter['current_occupancy'] ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Location:</label>
            <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($shelter['location']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Contact Email:</label>
            <input type="email" name="contact_email" class="form-control" value="<?= htmlspecialchars($shelter['contact_email']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Contact Phone:</label>
            <input type="text" name="contact_phone" class="form-control" value="<?= htmlspecialchars($shelter['contact_phone']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Description:</label>
            <textarea name="description" class="form-control" rows="4" required><?= htmlspecialchars($shelter['description']) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Update Shelter</button>
        <a href="view_shelters.php" class="btn btn-secondary ms-2">← Back to View Shelters</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
