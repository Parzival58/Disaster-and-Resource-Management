<?php
session_start();
include '../config.php';

// Redirect if admin is not logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get user ID
if (!isset($_GET['id'])) {
    echo "User ID missing!";
    exit();
}

$id = $_GET['id'];

// Fetch user info
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found!";
    exit();
}

// Update on form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name        = $_POST['name'];
    $username    = $_POST['username'];
    $email       = $_POST['email'];
    $phone       = $_POST['phone'];
    $address     = $_POST['address'];
    $blood_group = $_POST['blood_group'];
    $role        = $_POST['role'];

    $stmt = $conn->prepare("UPDATE users SET name=?, username=?, email=?, phone=?, address=?, blood_group=?, role=? WHERE id=?");
    $stmt->bind_param("sssssssi", $name, $username, $email, $phone, $address, $blood_group, $role, $id);

    if ($stmt->execute()) {
        header("Location: manage_users.php");
        exit();
    } else {
        echo "Error updating user!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('navbar.php'); ?>

    <div class="container mt-5">
        <h2 class="mb-4">Edit User Info</h2>

        <form method="post" class="card p-4 shadow">
            <div class="row">
                <div class="mb-3 col-md-6">
                    <label class="form-label">Name:</label>
                    <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($user['name']); ?>" required>
                </div>

                <div class="mb-3 col-md-6">
                    <label class="form-label">Username:</label>
                    <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($user['username']); ?>" required>
                </div>
            </div>

            <div class="row">
                <div class="mb-3 col-md-6">
                    <label class="form-label">Email:</label>
                    <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>
                </div>

                <div class="mb-3 col-md-6">
                    <label class="form-label">Phone:</label>
                    <input type="text" class="form-control" name="phone" value="<?= htmlspecialchars($user['phone']); ?>">
                </div>
            </div>

            <div class="row">
                <div class="mb-3 col-md-6">
                    <label class="form-label">Address:</label>
                    <input type="text" class="form-control" name="address" value="<?= htmlspecialchars($user['address']); ?>">
                </div>

                <div class="mb-3 col-md-3">
                    <label class="form-label">Blood Group:</label>
                    <select class="form-select" name="blood_group" required>
                        <option value="">Select</option>
                        <?php
                        $groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
                        foreach ($groups as $group) {
                            $selected = ($user['blood_group'] == $group) ? 'selected' : '';
                            echo "<option value='$group' $selected>$group</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3 col-md-3">
                    <label class="form-label">Role:</label>
                    <select class="form-select" name="role" required>
                        <option value="">Select Role</option>
                        <?php
                        $roles = ['admin', 'user'];
                        foreach ($roles as $r) {
                            $selected = ($user['role'] == $r) ? 'selected' : '';
                            echo "<option value='$r' $selected>$r</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Update User</button>
                <a href="manage_users.php" class="btn btn-secondary ms-2">Back to Manage Users</a>
            </div>
        </form>
    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
