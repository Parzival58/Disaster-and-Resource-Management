<?php
include('../config.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['station_name'];
    $contact = $_POST['station_contact_number'];
    $location = $_POST['location'];

    // Insert the new fire station data into the database
    $query = "INSERT INTO fire_service (station_name, station_contact_number, location) 
              VALUES ('$name', '$contact', '$location')";
    if ($conn->query($query)) {
        echo "<div class='alert alert-success'>Fire station added successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Fire Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2>Add Fire Station</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="station_name" class="form-label">Station Name</label>
            <input type="text" class="form-control" name="station_name" required>
        </div>
        <div class="mb-3">
            <label for="station_contact_number" class="form-label">Contact Number</label>
            <input type="text" class="form-control" name="station_contact_number" required>
        </div>
        <div class="mb-3">
            <label for="location" class="form-label">Location</label>
            <input type="text" class="form-control" name="location" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Fire Station</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
