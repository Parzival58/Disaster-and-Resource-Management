<?php
include('../config.php');

// Check if ID is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the fire station from the database
    $query = "DELETE FROM fire_service WHERE id = $id";
    if ($conn->query($query)) {
        header("Location: fire_view.php"); // Redirect back to the list
        exit();
    } else {
        echo "<div class='alert alert-danger'>Error deleting fire station: " . $conn->error . "</div>";
    }
} else {
    echo "<div class='alert alert-danger'>Invalid ID.</div>";
}
?>
