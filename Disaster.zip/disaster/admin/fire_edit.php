<?php
include('../config.php');

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM fire_service WHERE id = $id");
$row = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['station_name'];
    $contact = $_POST['station_contact_number'];
    $location = $_POST['location'];

    // Update the fire station record
    $conn->query("UPDATE fire_service SET station_name='$name', station_contact_number='$contact', location='$location' WHERE id=$id");
    header("Location: fire_view.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Fire Station</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2>Edit Fire Station</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="station_name" class="form-label">Station Name</label>
            <input type="text" class="form-control" name="station_name" value="<?= $row['station_name'] ?>" required>
        </div>
        <div class="mb-3">
            <label for="station_contact_number" class="form-label">Contact Number</label>
            <input type="text" class="form-control" name="station_contact_number" value="<?= $row['station_contact_number'] ?>" required>
        </div>
        <div class="mb-3">
            <label for="location" class="form-label">Location</label>
            <input type="text" class="form-control" name="location" value="<?= $row['location'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Fire Station</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
