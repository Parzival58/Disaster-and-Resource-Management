<?php
// admin/add_hospital.php

include '../config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Hospital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="container mt-5">
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['hospital_name'];
    $phone = $_POST['phone_number'];
    $location = $_POST['location'];
    $doctors = $_POST['doctors'];
    $nurses = $_POST['nurses'];
    $stored_blood = $_POST['stored_blood'];

    $stmt = $conn->prepare("INSERT INTO hospital (hospital_name, phone_number, location, doctors, nurses, stored_blood) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssiii", $name, $phone, $location, $doctors, $nurses, $stored_blood);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success mt-3'>Hospital added successfully.</div>";
    } else {
        echo "<div class='alert alert-danger mt-3'>Error: " . $stmt->error . "</div>";
    }

    $stmt->close();
}
?>

<h2 class="mb-4">Add Hospital</h2>

<form method="POST">
    <div class="mb-3">
        <label class="form-label">Hospital Name</label>
        <input type="text" class="form-control" name="hospital_name" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Phone Number</label>
        <input type="text" class="form-control" name="phone_number" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Location</label>
        <input type="text" class="form-control" name="location" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Doctors</label>
        <input type="number" class="form-control" name="doctors" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Nurses</label>
        <input type="number" class="form-control" name="nurses" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Stored Blood (Units)</label>
        <input type="number" class="form-control" name="stored_blood" required>
    </div>
    <button type="submit" class="btn btn-primary">Add Hospital</button>
</form>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
