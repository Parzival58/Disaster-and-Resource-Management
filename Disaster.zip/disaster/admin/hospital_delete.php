<?php
// admin/hospital_delete.php

include '../config.php';

// Check if ID is set and is a valid integer
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int) $_GET['id'];

    // Use prepared statement to safely delete
    $stmt = $conn->prepare("DELETE FROM hospital WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Redirect back to the hospital view page regardless
header("Location: hospital_view.php");
exit();
