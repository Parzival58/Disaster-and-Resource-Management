<?php
// admin/edit_hospital.php

include '../config.php';

// Validate and sanitize id parameter
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("<div class='alert alert-danger mt-3'>Invalid hospital ID.</div>");
}
$id = intval($_GET['id']);

// Fetch hospital data
$stmt = $conn->prepare("SELECT * FROM hospital WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows != 1) {
    die("<div class='alert alert-danger mt-3'>Hospital not found.</div>");
}
$row = $result->fetch_assoc();
$stmt->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['hospital_name'];
    $location = $_POST['location'];
    $phone = $_POST['phone_number'];
    $doctors = $_POST['doctors'];
    $nurses = $_POST['nurses'];
    $blood = $_POST['stored_blood'];

    $stmt = $conn->prepare("UPDATE hospital SET hospital_name=?, location=?, phone_number=?, doctors=?, nurses=?, stored_blood=? WHERE id=?");
    $stmt->bind_param("sssiiii", $name, $location, $phone, $doctors, $nurses, $blood, $id);

    if ($stmt->execute()) {
        header("Location: hospital_view.php");
        exit();
    } else {
        echo "<div class='alert alert-danger mt-3'>Error updating hospital: " . $stmt->error . "</div>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Hospital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin_dashboard.php">Disaster And Resource Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="admin_dashboard.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="manage_users.php">Manage Users</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_disaster_information.php">Add Disaster Information</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_shelters.php">Manage Shelters</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ambulance_view.php">Manage Ambulances</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="fire_view.php">Manage Fire Stations</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="hospital_view.php">Manage Hospitals</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="post_public_message.php">Public Message</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-danger" href="../logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-5">

<h2 class="mb-4">Edit Hospital</h2>

<form method="POST">
    <div class="mb-3">
        <label class="form-label">Hospital Name</label>
        <input type="text" class="form-control" name="hospital_name" value="<?= htmlspecialchars($row['hospital_name']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Location</label>
        <input type="text" class="form-control" name="location" value="<?= htmlspecialchars($row['location']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Phone Number</label>
        <input type="text" class="form-control" name="phone_number" value="<?= htmlspecialchars($row['phone_number']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Number of Doctors</label>
        <input type="number" class="form-control" name="doctors" value="<?= htmlspecialchars($row['doctors']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Number of Nurses</label>
        <input type="number" class="form-control" name="nurses" value="<?= htmlspecialchars($row['nurses']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Stored Blood (units)</label>
        <input type="number" class="form-control" name="stored_blood" value="<?= htmlspecialchars($row['stored_blood']) ?>" required>
    </div>
    <button type="submit" class="btn btn-primary">Update Hospital</button>
</form>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
