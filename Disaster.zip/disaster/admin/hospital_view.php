<?php
// admin/hospital_view.php

include '../config.php';

// Initialize search variable
$search = '';
$rows = [];

// Search handling with prepared statement
if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $search = trim($_GET['search']);
    $like = "%$search%";
    $stmt = $conn->prepare("SELECT * FROM hospital WHERE hospital_name LIKE ? OR location LIKE ?");
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM hospital");
}

if ($result) {
    $rows = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Hospitals</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
<h2 class="mb-4">Hospitals</h2>

<a href="hospital_add.php" class="btn btn-primary mb-3">Add Hospital</a>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3 ms-2">← Back to Home</a>

<form method="GET" class="mb-4">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Search by hospital name or location" value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn btn-primary">Search</button>
    </div>
</form>

<table class="table table-bordered table-hover">
    <thead class="table-dark">
        <tr>
            <th>#</th>
            <th>Hospital Name</th>
            <th>Phone</th>
            <th>Doctors</th>
            <th>Nurses</th>
            <th>Blood Units</th>
            <th>Location</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($rows) > 0): ?>
            <?php $serial = 1; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td><?= $serial++ ?></td>
                    <td><?= htmlspecialchars($row['hospital_name']) ?></td>
                    <td><?= htmlspecialchars($row['phone_number']) ?></td>
                    <td><?= htmlspecialchars($row['doctors']) ?></td>
                    <td><?= htmlspecialchars($row['nurses']) ?></td>
                    <td><?= htmlspecialchars($row['stored_blood']) ?></td>
                    <td><?= htmlspecialchars($row['location']) ?></td>
                    <td>
                        <a href="hospital_edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="hospital_delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this hospital?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="8" class="text-center">No hospitals found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
