<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id']) || empty($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access denied.");
}

if (isset($_GET['action'], $_GET['request_id'])) {
    $action = $_GET['action'];
    $request_id = (int) $_GET['request_id'];

    if (in_array($action, ['approve', 'reject']) && $request_id > 0) {
        if ($action === 'approve') {
            $conn->query("UPDATE volunteer_requests SET status='approved' WHERE id=$request_id") or die($conn->error);
            $user_query = $conn->query("SELECT user_id FROM volunteer_requests WHERE id=$request_id") or die($conn->error);
            if ($user_row = $user_query->fetch_assoc()) {
                $user_id = (int) $user_row['user_id'];
                $conn->query("UPDATE users SET is_volunteer=1 WHERE id=$user_id") or die($conn->error);
            }
        } elseif ($action === 'reject') {
            $conn->query("UPDATE volunteer_requests SET status='rejected' WHERE id=$request_id") or die($conn->error);
        }

        header("Location: manage_volunteers.php");
        exit();
    }
}

$request_query = "
    SELECT vr.id, vr.request_date, u.username, u.email
    FROM volunteer_requests vr
    JOIN users u ON vr.user_id = u.id
    WHERE vr.status = 'pending'
";
$requests = $conn->query($request_query) or die($conn->error);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Volunteer Requests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .table-hover tbody tr:hover {
            background-color: #f8f9fa;
        }
        .badge-username {
            font-size: 0.9rem;
            font-weight: 500;
            background-color: #0d6efd;
            color: #fff;
        }
        .header-icon {
            font-size: 1.5rem;
            margin-right: 10px;
            color: #0d6efd;
        }
    </style>
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4"><i class="fas fa-user-check header-icon"></i>Manage Volunteer Requests</h2>

    <?php if ($requests->num_rows > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Request Date</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $requests->fetch_assoc()): ?>
                        <tr>
                            <td><span class="badge badge-username"><?= htmlspecialchars($row['username']) ?></span></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td><?= date('d M Y, h:i A', strtotime($row['request_date'])) ?></td>
                            <td class="text-center">
                                <a href="?action=approve&request_id=<?= $row['id'] ?>"
                                   class="btn btn-outline-success btn-sm me-2"
                                   onclick="return confirm('Are you sure you want to approve this request?');">
                                    ✅ Approve
                                </a>
                                <a href="?action=reject&request_id=<?= $row['id'] ?>"
                                   class="btn btn-outline-danger btn-sm"
                                   onclick="return confirm('Are you sure you want to reject this request?');">
                                    ❌ Reject
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">📭 No pending volunteer requests.</div>
    <?php endif; ?>

    <div class="mt-4">
        <a href="admin_dashboard.php" class="btn btn-secondary">← Back to Admin Dashboard</a>
    </div>
</div>
<!-- FontAwesome Icons (already included) -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<!-- ✅ Add this line below to fix dropdown issue -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

</body>
</html>
