<!-- Include Bootstrap Icons CDN -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin_dashboard.php">
      <i class="bi bi-shield-exclamation"></i> Disaster & Resource Management
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i> Home</a>
        </li>

        <!-- Manage Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarManageDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-tools"></i> Manage
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarManageDropdown">

            <!-- 🚨 Emergency Services -->
            <li><h6 class="dropdown-header">🚨 Emergency Services</h6></li>
            <li><a class="dropdown-item" href="ambulance_view.php"><i class="bi bi-truck-front-fill"></i> Ambulances</a></li>
            <li><a class="dropdown-item" href="fire_view.php"><i class="bi bi-fire"></i> Fire Stations</a></li>
            <li><a class="dropdown-item" href="hospital_view.php"><i class="bi bi-hospital"></i> Hospitals</a></li>
            <li><a class="dropdown-item" href="police_view.php"><i class="bi bi-shield-lock-fill"></i> Police Stations</a></li>

            <li><hr class="dropdown-divider"></li>

            <!-- 🏗️ Infrastructure & Users -->
            <li><h6 class="dropdown-header">🏗️ Infrastructure & Users</h6></li>
            <li><a class="dropdown-item" href="manage_users.php"><i class="bi bi-people-fill"></i> Users</a></li>
            <li><a class="dropdown-item" href="view_shelters.php"><i class="bi bi-house-heart-fill"></i> Shelters</a></li>
            <li><a class="dropdown-item" href="view_resources.php"><i class="bi bi-boxes"></i> Resources</a></li>
            <li><a class="dropdown-item" href="manage_volunteers.php"><i class="bi bi-person-badge-fill"></i> Volunteers</a></li>
            <li><a class="dropdown-item" href="sos_view.php"><i class="bi bi-exclamation-circle-fill text-danger"></i> SOS Requests</a></li>

            <li><hr class="dropdown-divider"></li>

            <!-- New option for Resource Requests -->
            <li><a class="dropdown-item" href="resource_requests.php"><i class="bi bi-box-arrow-in-down-right"></i> View Resource Requests</a></li>
          </ul>
        </li>

        <!-- Other Navbar Links -->
        <li class="nav-item">
          <a class="nav-link" href="add_disaster_information.php"><i class="bi bi-plus-square-fill"></i> Add Disaster</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="post_public_message.php"><i class="bi bi-megaphone-fill"></i> Public Message</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-danger" href="../index.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
