<?php
include '../config.php';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $station_name = trim($_POST['station_name']);
    $contact_number = trim($_POST['contact_number']);
    $location = trim($_POST['location']);

    // Simple validation
    if (empty($station_name) || empty($contact_number) || empty($location)) {
        $error = "All fields are required.";
    } else {
        // Use prepared statement to insert data
        $stmt = $conn->prepare("INSERT INTO police (station_name, contact_number, location) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $station_name, $contact_number, $location);

        if ($stmt->execute()) {
            header("Location: police_view.php");
            exit();
        } else {
            $error = "Error adding police station: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Police Station</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Add Police Station</h2>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Station Name</label>
            <input type="text" class="form-control" name="station_name" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Contact Number</label>
            <input type="text" class="form-control" name="contact_number" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" class="form-control" name="location" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Police Station</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
