<?php
include '../config.php'; // Adjust the path to your config file

// Check if ID is set and is a valid integer
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int) $_GET['id'];

    // Prepare and execute the DELETE query using a prepared statement to avoid SQL injection
    $stmt = $conn->prepare("DELETE FROM police WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        header("Location: police_view.php");
        exit();
    } else {
        echo "<div class='alert alert-danger'>Error deleting police station: " . $stmt->error . "</div>";
    }

    // Close the prepared statement
    $stmt->close();
} else {
    echo "<div class='alert alert-danger'>Invalid request.</div>";
}
?>
