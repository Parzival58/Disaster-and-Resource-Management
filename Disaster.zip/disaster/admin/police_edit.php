<?php
include '../config.php';

// Validate and sanitize the 'id' parameter
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("<div class='alert alert-danger'>Invalid police station ID.</div>");
}

$id = intval($_GET['id']);

// Fetch the police station data from the database
$stmt = $conn->prepare("SELECT * FROM police WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows != 1) {
    die("<div class='alert alert-danger'>Police station not found.</div>");
}

$row = $result->fetch_assoc();
$stmt->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $station_name = trim($_POST['station_name']);
    $contact_number = trim($_POST['contact_number']);
    $location = trim($_POST['location']);

    // Simple validation
    if (empty($station_name) || empty($contact_number) || empty($location)) {
        $error = "All fields are required.";
    } else {
        // Use a prepared statement to safely update the police station
        $update_stmt = $conn->prepare("UPDATE police SET station_name=?, contact_number=?, location=? WHERE id=?");
        $update_stmt->bind_param("sssi", $station_name, $contact_number, $location, $id);

        if ($update_stmt->execute()) {
            header("Location: police_view.php");
            exit();
        } else {
            $error = "Error updating police station: " . $update_stmt->error;
        }

        $update_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Police Station</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Edit Police Station</h2>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Station Name</label>
            <input type="text" class="form-control" name="station_name" value="<?= htmlspecialchars($row['station_name']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Contact Number</label>
            <input type="text" class="form-control" name="contact_number" value="<?= htmlspecialchars($row['contact_number']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" class="form-control" name="location" value="<?= htmlspecialchars($row['location']) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Police Station</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
