<?php
include '../config.php';

// Initialize search variable
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$rows = [];

// Search handling with prepared statement
if (!empty($search)) {
    $like = "%$search%";
    $stmt = $conn->prepare("SELECT * FROM police WHERE station_name LIKE ? OR location LIKE ?");
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM police");
}

if ($result) {
    $rows = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Police Stations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Police Stations</h2>
    <a href="police_add.php" class="btn btn-primary mb-3">Add Police Station</a>
    <a href="admin_dashboard.php" class="btn btn-secondary mb-3 ms-2">← Back to Home</a>

    <!-- Search Form -->
    <form method="GET" class="mb-3">
        <input type="text" name="search" class="form-control" placeholder="Search by name or location" value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn btn-primary mt-2">Search</button>
    </form>

    <!-- Police Stations Table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Station Name</th>
                <th>Contact Number</th>
                <th>Location</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($rows) > 0): ?>
                <?php $serial = 1; ?>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td><?= $serial++ ?></td>
                        <td><?= htmlspecialchars($row['station_name']) ?></td>
                        <td><?= htmlspecialchars($row['contact_number']) ?></td>
                        <td><?= htmlspecialchars($row['location']) ?></td>
                        <td>
                            <a href="police_edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="police_delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this station?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center">No police stations found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
