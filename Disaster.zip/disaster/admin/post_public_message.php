<?php
session_start();
include '../config.php';

// Ensure admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id']; // Correct user_id

// Fetch disaster options
$disaster_options = $conn->query("SELECT id, name FROM disaster_information ORDER BY id DESC");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $disaster_id = intval($_POST['disaster_id']);
    $message = trim($_POST['message']);
    $evacuation_priority = trim($_POST['evacuation_priority']);

    if (!empty($message) && !empty($evacuation_priority) && $disaster_id > 0) {
        // Check if disaster exists
        $check = $conn->prepare("SELECT COUNT(*) as count FROM disaster_information WHERE id = ?");
        $check->bind_param("i", $disaster_id);
        $check->execute();
        $result = $check->get_result()->fetch_assoc();
        if ($result['count'] == 0) {
            $error = "❌ Selected disaster does not exist.";
        } else {
            // Insert message using admin's user_id
            $stmt = $conn->prepare("
                INSERT INTO public_message (message, evacuation_priority, posted_by, disasters_id)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param("ssii", $message, $evacuation_priority, $admin_id, $disaster_id);
            if ($stmt->execute()) {
                $success = "✅ Message posted successfully!";
            } else {
                $error = "❌ Error: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        $error = "❌ Please fill all fields and select a valid disaster.";
    }
}

// Fetch messages with disaster and user info
$result = $conn->query("
    SELECT pm.*, d.name AS disaster_name, d.severity AS severity_level, u.username
    FROM public_message pm
    JOIN disaster_information d ON pm.disasters_id = d.id
    JOIN users u ON pm.posted_by = u.id
    ORDER BY pm.date_posted DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Post Public Message</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">📝 Post a Public Message</h2>

    <a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" class="card p-4 shadow-sm mb-4">
        <div class="mb-3">
            <label for="disaster_id" class="form-label"><strong>Select Disaster:</strong></label>
            <select name="disaster_id" id="disaster_id" class="form-select" required>
                <option value="">-- Select Disaster --</option>
                <?php while ($row = $disaster_options->fetch_assoc()): ?>
                    <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="evacuation_priority" class="form-label"><strong>Evacuation Priority:</strong></label>
            <input type="text" name="evacuation_priority" id="evacuation_priority" class="form-control" required placeholder="e.g. High, Medium, Low">
        </div>

        <div class="mb-3">
            <label for="message" class="form-label"><strong>Message:</strong></label>
            <textarea name="message" id="message" rows="5" class="form-control" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Post Message</button>
    </form>

    <h3>📢 All Public Messages</h3>

    <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="card mb-3 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">
                        <?= htmlspecialchars($row['disaster_name']) ?>
                        <span class="badge bg-danger ms-2">Severity: <?= htmlspecialchars($row['severity_level']) ?></span>
                        <span class="badge bg-warning text-dark ms-1">Evacuation Priority: <?= htmlspecialchars($row['evacuation_priority']) ?></span>
                    </h5>
                    <p class="card-text"><?= nl2br(htmlspecialchars($row['message'])) ?></p>
                    <p class="card-text">
                        <small class="text-muted">
                            Posted on <?= htmlspecialchars($row['date_posted']) ?> by <strong><?= htmlspecialchars($row['username']) ?></strong>
                        </small>
                    </p>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p class="text-muted">No public messages posted yet.</p>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
