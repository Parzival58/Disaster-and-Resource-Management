<?php
include 'config.php';

// Handle approve or reject actions
if (isset($_POST['action']) && isset($_POST['request_id'])) {
    $request_id = $_POST['request_id'];
    $action = $_POST['action'];

    // Determine the new status based on action
    $status = ($action === 'approve') ? 'allocated' : 'rejected';

    // Update the status in the database
    $updateQuery = "UPDATE resource_request SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param('si', $status, $request_id);

    if ($stmt->execute()) {
        // If approved, redirect to the allocate resource page
        if ($status === 'allocated') {
            header("Location: allocate_resource.php");
            exit();
        }
    } else {
        echo "<script>alert('Error updating request status'); window.location.href='resource_requests.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resource Requests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>🛠️ Resource Requests</h2>

    <table class="table table-bordered table-striped">
        <thead class="table-light">
            <tr>
                <th>Serial</th>
                <th>Resource</th>
                <th>Type</th>
                <th>Quantity</th>
                <th>Requested By</th>
                <th>Shelter</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = 1;
            $sql = "SELECT rr.*, u.name AS requested_by, s.name AS shelter_name
                    FROM resource_request rr
                    LEFT JOIN users u ON rr.requested_by_user_id = u.id
                    LEFT JOIN shelter_information s ON rr.shelter_id = s.id
                    ORDER BY rr.request_date DESC";

            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $status_label = $row['status'] === 'allocated' ? 'Allocated' : ($row['status'] === 'rejected' ? 'Rejected' : 'Pending');
                    echo "<tr>
                            <td>{$serial}</td>
                            <td>" . htmlspecialchars($row['resource_name']) . "</td>
                            <td>" . htmlspecialchars($row['type']) . "</td>
                            <td>" . htmlspecialchars($row['requested_quantity']) . "</td>
                            <td>" . htmlspecialchars($row['requested_by']) . "</td>
                            <td>" . htmlspecialchars($row['shelter_name']) . "</td>
                            <td>" . htmlspecialchars($row['request_date']) . "</td>
                            <td>{$status_label}</td>
                            <td>
                                <!-- Only allow approve/reject if status is still pending -->
                                " . ($row['status'] === 'pending' ? "
                                    <form method='POST' style='display:inline;'>
                                        <input type='hidden' name='request_id' value='" . $row['id'] . "'>
                                        <button type='submit' name='action' value='approve' class='btn btn-success btn-sm'>Approve</button>
                                    </form>
                                    <form method='POST' style='display:inline;'>
                                        <input type='hidden' name='request_id' value='" . $row['id'] . "'>
                                        <button type='submit' name='action' value='reject' class='btn btn-danger btn-sm'>Reject</button>
                                    </form>
                                " : "<span class='text-muted'>Action taken</span>") . "
                            </td>
                          </tr>";
                    $serial++;
                }
            } else {
                echo "<tr><td colspan='9' class='text-center'>No requests found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
