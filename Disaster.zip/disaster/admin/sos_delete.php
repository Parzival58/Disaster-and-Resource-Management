<?php
include 'db_connect.php';
$id = $_GET['id'];
$conn->query("DELETE FROM sos WHERE id = $id");
header("Location: sos_view.php");
?>
