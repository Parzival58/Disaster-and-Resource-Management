<?php
include 'config.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM sos WHERE id = $id");
$row = $result->fetch_assoc();
$assigned_units = explode(',', $row['assigned_unit']); // For pre-selecting

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['NAME'];
    $phone = $_POST['phone'];
    $location = $_POST['location'];
    $reason = $_POST['Reason'];
    $status = $_POST['STATUS'];
    $assigned_units = isset($_POST['assigned_unit']) ? $_POST['assigned_unit'] : [];
    $assigned_units_str = implode(',', $assigned_units);

    $stmt = $conn->prepare("UPDATE sos SET NAME = ?, phone = ?, location = ?, Reason = ?, STATUS = ?, assigned_unit = ? WHERE id = ?");
    $stmt->bind_param("ssssssi", $name, $phone, $location, $reason, $status, $assigned_units_str, $id);
    $stmt->execute();

    header("Location: sos_view.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit SOS Request</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

<h2 class="mb-4">Edit SOS Request</h2>

<form method="post" class="w-50">
    <div class="mb-3">
        <label class="form-label">Name:</label>
        <input type="text" name="NAME" value="<?= htmlspecialchars($row['NAME']) ?>" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Phone Number:</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($row['phone']) ?>" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Location:</label>
        <input type="text" name="location" value="<?= htmlspecialchars($row['location']) ?>" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Reason:</label>
        <textarea name="Reason" class="form-control" required><?= htmlspecialchars($row['Reason']) ?></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">Status:</label>
        <select name="STATUS" class="form-select" required>
            <option value="Pending" <?= $row['STATUS'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
            <option value="Ongoing" <?= $row['STATUS'] == 'Ongoing' ? 'selected' : '' ?>>Ongoing</option>
            <option value="Solved" <?= $row['STATUS'] == 'Solved' ? 'selected' : '' ?>>Solved</option>
        </select>
    </div>

    <div class="mb-4">
        <label class="form-label">Assigned Units:</label>
        <select name="assigned_unit[]" class="form-select" multiple>
            <option value="Ambulance" <?= in_array("Ambulance", $assigned_units) ? 'selected' : '' ?>>Ambulance</option>
            <option value="Fire Service" <?= in_array("Fire Service", $assigned_units) ? 'selected' : '' ?>>Fire Service</option>
            <option value="Police" <?= in_array("Police", $assigned_units) ? 'selected' : '' ?>>Police</option>
        </select>
        <div class="form-text">Hold Ctrl (Windows) or Command (Mac) to select multiple.</div>
    </div>

    <button type="submit" class="btn btn-warning">Update</button>
</form>

</body>
</html>
