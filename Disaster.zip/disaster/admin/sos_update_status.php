<?php
include('../config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $status = $_POST['STATUS'];
    $assigned_units = isset($_POST['assigned_unit']) ? $_POST['assigned_unit'] : [];

    // Join multiple selected units into comma-separated string
    $assigned_units_str = implode(',', $assigned_units);

    $stmt = $conn->prepare("UPDATE sos SET STATUS = ?, assigned_unit = ? WHERE id = ?");
    $stmt->bind_param("ssi", $status, $assigned_units_str, $id);

    if ($stmt->execute()) {
        header("Location: sos_view.php");
        exit;
    } else {
        echo "Error updating record.";
    }
}
?>
