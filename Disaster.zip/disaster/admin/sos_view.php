<?php
include('../config.php');

// --- Pagination & Filter Setup ---
$entriesPerPage = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $entriesPerPage;

// --- Filter Setup ---
$filter = isset($_GET['status']) ? $_GET['status'] : '';

// --- Build WHERE Clause if Filter is Set ---
$whereClause = '';
$params = [];
if ($filter && in_array($filter, ['Pending', 'Ongoing', 'Solved'])) {
    $whereClause = "WHERE STATUS = ?";
    $params[] = $filter;
}

// --- Count Total Entries for Pagination ---
$countQuery = "SELECT COUNT(*) as total FROM sos $whereClause";
$stmt = $conn->prepare($countQuery);
if ($params) {
    $stmt->bind_param("s", $params[0]);
}
$stmt->execute();
$countResult = $stmt->get_result()->fetch_assoc();
$totalEntries = $countResult['total'];
$totalPages = ceil($totalEntries / $entriesPerPage);

// --- Fetch Paginated Results ---
$query = "SELECT * FROM sos $whereClause ORDER BY FIELD(STATUS, 'Pending', 'Ongoing', 'Solved') LIMIT ? OFFSET ?";
$stmt = $conn->prepare($query);
if ($params) {
    $stmt->bind_param("sii", $params[0], $entriesPerPage, $offset);
} else {
    $stmt->bind_param("ii", $entriesPerPage, $offset);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SOS Requests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">SOS Requests</h2>

    <!-- Filter by Priority -->
    <form method="GET" class="mb-3 d-flex align-items-center gap-2">
        <label class="form-label fw-bold me-2">Filter by Status:</label>
        <select name="status" class="form-select w-auto" onchange="this.form.submit()">
            <option value="">All</option>
            <option value="Pending" <?= $filter === 'Pending' ? 'selected' : '' ?>>Pending</option>
            <option value="Ongoing" <?= $filter === 'Ongoing' ? 'selected' : '' ?>>Ongoing</option>
            <option value="Solved" <?= $filter === 'Solved' ? 'selected' : '' ?>>Solved</option>
        </select>
    </form>
    <a href="admin_dashboard.php" class="btn btn-secondary mb-3 ms-2">← Back to Home</a>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Location</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Assigned Unit(s)</th>
                <th>Update</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = $offset + 1;
            while ($row = $result->fetch_assoc()):
                $assigned_units = explode(",", $row['assigned_unit']);
            ?>
                <tr>
                    <td><?= $serial++ ?></td>
                    <td><?= htmlspecialchars($row['NAME']) ?></td>
                    <td><?= htmlspecialchars($row['phone']) ?></td>
                    <td><?= htmlspecialchars($row['location']) ?></td>
                    <td><?= htmlspecialchars($row['Reason']) ?></td>
                    <td><?= htmlspecialchars($row['STATUS']) ?></td>
                    <td><?= htmlspecialchars($row['assigned_unit']) ?></td>
                    <td>
                        <form method="POST" action="sos_update_status.php">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">

                            <label class="form-label fw-bold mb-1">Status:</label>
                            <select name="STATUS" class="form-select form-select-sm mb-2">
                                <option value="Pending" <?= $row['STATUS'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="Ongoing" <?= $row['STATUS'] == 'Ongoing' ? 'selected' : '' ?>>Ongoing</option>
                                <option value="Solved" <?= $row['STATUS'] == 'Solved' ? 'selected' : '' ?>>Solved</option>
                            </select>

                            <label class="form-label fw-bold mb-1">Assigned Unit:</label>
                            <select name="assigned_unit[]" class="form-select form-select-sm mb-2" multiple>
                                <option value="Ambulance" <?= in_array('Ambulance', $assigned_units) ? 'selected' : '' ?>>Ambulance</option>
                                <option value="Fire Service" <?= in_array('Fire Service', $assigned_units) ? 'selected' : '' ?>>Fire Service</option>
                                <option value="Police" <?= in_array('Police', $assigned_units) ? 'selected' : '' ?>>Police</option>
                            </select>

                            <input type="submit" class="btn btn-sm btn-primary" value="Update">
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <nav>
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $i ?>&status=<?= urlencode($filter) ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
