<?php
session_start();
include '../config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$result = $conn->query("
    SELECT blood_group, SUM(quantity) AS total_quantity
    FROM blood_donations
    GROUP BY blood_group
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Blood Bank Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>🧪 Blood Bank Inventory</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Blood Group</th>
                <th>Total Quantity (ml)</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['blood_group']) ?></td>
                    <td><?= $row['total_quantity'] ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
