<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include("../config.php");

// Restrict to admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch all resources along with their shelter names
$resourceQuery = "
    SELECT r.*, s.name AS shelter_name 
    FROM `resources` r
    LEFT JOIN `shelter_information` s ON r.shelter_id = s.id
";
$resourceResult = $conn->query($resourceQuery);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Resources</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-3">Manage Resources</h2>
    <a href="add_resource.php" class="btn btn-primary mb-3">Add New Resource</a>
    <a href="admin_dashboard.php" class="btn btn-secondary mb-3 ms-2">← Back to Home</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Type</th>
                <th>Quantity</th>
                <th>Shelter Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($resource = $resourceResult->fetch_assoc()): ?>
            <tr>
                <td><?= $resource['id'] ?></td>
                <td><?= $resource['name'] ?></td>
                <td><?= $resource['type'] ?></td>
                <td><?= $resource['quantity'] ?></td>
                <td><?= $resource['shelter_name'] ?></td>
                <td>
                    <a href="edit_resource.php?id=<?= $resource['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="delete_resource.php?id=<?= $resource['id'] ?>" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
