<?php
session_start();
include('db.php');

// Check admin access
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? null;
$name = $_GET['name'] ?? null;

if ($id && $name) {
    $stmt = $conn->prepare("DELETE FROM disasters WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: view_disasters.php?deleted=" . urlencode($name));
        exit();
    } else {
        die("Error deleting disaster.");
    }
} else {
    die("Invalid request.");
}
?>
