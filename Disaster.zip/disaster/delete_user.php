<?php
session_start();
include('db.php');

// Check admin access
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Check if 'id' is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch user data
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // If user exists
    if ($user) {
        // Check if the user is trying to delete their own account or another admin's account
        if ($_SESSION['username'] == $user['username']) {
            header("Location: view_users.php?error=unauthorized_delete");
            exit();
        }

        // Check if the user to be deleted is an admin
        if ($user['role'] == 'admin' && $user['username'] != $_SESSION['username']) {
            header("Location: view_users.php?error=unauthorized_delete");
            exit();
        }

        // Delete the user from the database
        $deleteStmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $deleteStmt->bind_param("i", $id);

        if ($deleteStmt->execute()) {
            header("Location: view_users.php?deleted=true");
            exit();
        } else {
            header("Location: view_users.php?error=delete_failed");
            exit();
        }
    } else {
        // User not found
        header("Location: view_users.php?error=user_not_found");
        exit();
    }
} else {
    // No id provided
    header("Location: view_users.php?error=no_id_provided");
    exit();
}
?>
