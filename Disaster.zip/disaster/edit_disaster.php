<?php
session_start();
include('db.php');

// Check admin access
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? null;

// Fetch disaster info
$stmt = $conn->prepare("SELECT * FROM disasters WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$disaster = $result->fetch_assoc();

if (!$disaster) {
    die("Disaster not found!");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $place = $_POST['place'];
    $severity = $_POST['severity'];
    $year = $_POST['year'];
    $duration = $_POST['duration'];

    $stmt = $conn->prepare("UPDATE disasters SET name=?, place=?, severity=?, year=?, duration=? WHERE id=?");
    $stmt->bind_param("sssiii", $name, $place, $severity, $year, $duration, $id);

    if ($stmt->execute()) {
        header("Location: view_disasters.php?updated=" . urlencode($name));
        exit();
    } else {
        $error_message = "Error updating disaster.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Disaster</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php include 'header.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4 text-center">Edit Disaster</h2>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?= $error_message ?></div>
    <?php endif; ?>

    <form action="" method="POST" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Disaster Name</label>
            <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($disaster['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Place</label>
            <input type="text" class="form-control" name="place" value="<?= htmlspecialchars($disaster['place']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Severity</label>
            <select class="form-control" name="severity" required>
                <option value="Low" <?= $disaster['severity'] == 'Low' ? 'selected' : '' ?>>Low</option>
                <option value="Medium" <?= $disaster['severity'] == 'Medium' ? 'selected' : '' ?>>Medium</option>
                <option value="High" <?= $disaster['severity'] == 'High' ? 'selected' : '' ?>>High</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Year</label>
            <input type="number" class="form-control" name="year" value="<?= htmlspecialchars($disaster['year']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Duration (days)</label>
            <input type="number" class="form-control" name="duration" value="<?= htmlspecialchars($disaster['duration']) ?>" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Update Disaster</button>
    </form>

    <div class="text-center mt-3">
        <a href="view_disasters.php" class="btn btn-secondary btn-sm">Back to Disasters</a>
    </div>
</div>

</body>
</html>
