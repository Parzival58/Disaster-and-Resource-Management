<?php
session_start();
include('db.php');

// Check admin access
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? null;

// Fetch user info
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("User not found!");
}

// Prevent editing other admins
if ($user['role'] == 'admin' && $user['username'] != $_SESSION['username']) {
    $_SESSION['error_message'] = "You are not authorized to edit other admin's data.";
    header("Location: view_users.php");
    exit();
}

// Update user if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone_number'];
    $language = $_POST['language'];
    $blood_group = $_POST['blood_group'];
    $role = $_POST['role'];

    $stmt = $conn->prepare("UPDATE users SET name=?, username=?, email=?, phone_number=?, language=?, blood_group=?, role=? WHERE id=?");
    $stmt->bind_param("sssssssi", $name, $username, $email, $phone, $language, $blood_group, $role, $id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "User <strong>" . htmlspecialchars($user['username']) . "</strong> updated successfully.";
        header("Location: view_users.php");
        exit();
    } else {
        $error_message = "Error updating user.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include 'header.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4 text-center">Edit User</h2>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger text-center"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <form action="" method="POST" class="card p-4 shadow-sm">

        <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Phone Number</label>
            <input type="text" class="form-control" name="phone_number" value="<?= htmlspecialchars($user['phone_number']) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Language</label>
            <input type="text" class="form-control" name="language" value="<?= htmlspecialchars($user['language']) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Blood Group</label>
            <input type="text" class="form-control" name="blood_group" value="<?= htmlspecialchars($user['blood_group']) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Role</label>
            <select name="role" class="form-select" required>
                <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>User</option>
                <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary w-100">Update User</button>
    </form>

    <div class="text-center mt-3">
        <a href="view_users.php" class="btn btn-secondary btn-sm">Back to All Users</a>
    </div>
</div>

</body>
</html>
