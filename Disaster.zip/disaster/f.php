<?php
$password = 'admin'; // Use the password you want to hash
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
echo $hashedPassword;  // This will output the hashed password
?>
