<?php
// session_start();  // You DON'T need session_start here — start session in individual pages
?>
<!-- Common Header (Top Navbar) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<nav class="navbar navbar-light bg-white shadow-sm mb-4">
    <div class="container-fluid d-flex justify-content-between align-items-center">
        <!-- Left: Website Name -->
        <a class="navbar-brand fw-bold fs-4" href="admin_dashboard.php">Disaster Resource System</a>

        <!-- Right: User Dropdown + Menu Button -->
        <div class="d-flex align-items-center">

            <!-- User Dropdown -->
            <div class="dropdown me-2">
                <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="https://i.pravatar.cc/30" alt="User Icon" class="rounded-circle">
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="#">Profile</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                </ul>
            </div>

            <!-- Menu Button triggers Offcanvas -->
            <button class="btn btn-outline-secondary" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu">
                <i class="fas fa-bars"></i>
            </button>

        </div>
    </div>
</nav>

<!-- Offcanvas Sidebar (Admin Menu) -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="sidebarMenu">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Admin Menu</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
        <a href="view_shelters.php" class="btn btn-primary w-100 mb-2">Manage Shelters</a>
        <a href="view_disasters.php" class="btn btn-primary w-100 mb-2">Manage Disasters</a>
        <a href="view_resources.php" class="btn btn-primary w-100 mb-2">Manage Resources</a>
        <a href="view_users.php" class="btn btn-primary w-100 mb-2">Manage Users</a>
        <a href="logout.php" class="btn btn-danger w-100 mt-4">Logout</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
