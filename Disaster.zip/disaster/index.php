<?php
include("config.php");

// Fetch recent disasters
$disasters = $conn->query("SELECT * FROM disaster_information ORDER BY date DESC LIMIT 3");

// Fetch recent public messages with disaster and admin info
$messages = $conn->query("
    SELECT pm.*, d.name AS disaster_name, u.name AS admin_name
    FROM public_message pm
    LEFT JOIN disaster_information d ON pm.disasters_id = d.id
    LEFT JOIN users u ON pm.posted_by = u.id
    ORDER BY pm.date_posted DESC
    LIMIT 3
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Disaster and Resource Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .custom-home-navbar {
            background-color: rgb(69, 148, 148);
        }
        .custom-home-navbar .navbar-brand,
        .custom-home-navbar .nav-link {
            color: white !important;
        }
        .custom-home-navbar .nav-link:hover {
            color: #ddd !important;
        }
        .jumbotron {
            height: 450px;
            background: url('img/disaster.jpg') center center/cover no-repeat;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
            background-blend-mode: overlay;
            background-color: rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>

<?php include('navbar.php'); ?>

<!-- Jumbotron -->
<div class="jumbotron mb-5">
    <div class="container">
        <h1 class="display-4">Welcome to Disaster and Resource Management System</h1>
        <p class="lead">Stay informed. Stay safe. Stay prepared.</p>
    </div>
</div>

<div class="container">

    <!-- Recent Disasters -->
    <h2 class="mb-4">🧭 Recent Disasters</h2>
    <div class="row">
        <?php while($row = $disasters->fetch_assoc()): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted"><?= htmlspecialchars($row['type']) ?></h6>
                        <p class="card-text"><?= nl2br(htmlspecialchars($row['description'])) ?></p>
                        <p><strong>Severity:</strong> <?= htmlspecialchars($row['severity']) ?></p>
                    </div>
                    <div class="card-footer text-muted small">
                        <small>Occurred: <?= htmlspecialchars($row['date']) ?> | <?= htmlspecialchars($row['location']) ?></small>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>


    <!-- Recent Public Messages -->
    <h2 class="mb-4">📢 Recent Public Messages</h2>
    <div class="row">
        <?php while($row = $messages->fetch_assoc()): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 border-info shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">
                            <?= htmlspecialchars($row['disaster_name']) ?>
                        </h5>
                        <h6>
                            <span class="badge bg-warning text-dark">Evacuation Priority: <?= htmlspecialchars($row['evacuation_priority']) ?></span>
                        </h6>
                        <p class="card-text mt-2"><?= nl2br(htmlspecialchars($row['message'])) ?></p>
                    </div>
                    <div class="card-footer text-muted small">
                        Posted on <?= htmlspecialchars($row['date_posted']) ?> by <strong><?= htmlspecialchars($row['admin_name']) ?></strong>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    

</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center p-3 mt-5">
    &copy; <?= date('Y') ?> Disaster and Resource Management System | All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
