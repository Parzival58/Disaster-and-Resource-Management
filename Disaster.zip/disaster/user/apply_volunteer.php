<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user already has a pending or approved request
$check_query = $conn->prepare("SELECT status FROM volunteer_requests WHERE user_id = ?");
$check_query->bind_param("i", $user_id);
$check_query->execute();
$check_result = $check_query->get_result();

$request_exists = false;
$request_status = '';

if ($check_result->num_rows > 0) {
    $row = $check_result->fetch_assoc();
    $request_exists = true;
    $request_status = $row['status'];
}

// Handle new request submission
if (isset($_POST['submit_request']) && !$request_exists) {
    $insert_query = $conn->prepare("INSERT INTO volunteer_requests (user_id, status) VALUES (?, 'pending')");
    $insert_query->bind_param("i", $user_id);
    $insert_query->execute();
    header("Location: apply_volunteer.php?success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Request to be a Volunteer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background-color: #f9f9f9;
        }
        .volunteer-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            padding: 30px;
            max-width: 600px;
            margin: auto;
        }
        h2 {
            text-align: center;
            margin-bottom: 25px;
        }
        .btn-back {
            background-color: #6c757d;
            border: none;
        }
    </style>
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-5">
    <div class="volunteer-container">
        <h2>🙋 Request to Become a Volunteer</h2>

        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">✅ Your volunteer request has been submitted and is pending admin approval.</div>
        <?php endif; ?>

        <?php if ($request_exists): ?>
            <?php if ($request_status === 'pending'): ?>
                <div class="alert alert-warning">Your request is <strong>pending approval</strong> by the admin.</div>
            <?php elseif ($request_status === 'approved'): ?>
                <div class="alert alert-success">🎉 You are already approved as a volunteer!</div>
            <?php elseif ($request_status === 'rejected'): ?>
                <div class="alert alert-danger">Your previous volunteer request was <strong>rejected</strong>. You may contact an admin for more details.</div>
            <?php endif; ?>
        <?php else: ?>
            <form method="post" class="text-center">
                <button type="submit" name="submit_request" class="btn btn-primary">Request to be a Volunteer</button>
            </form>
        <?php endif; ?>

        <div class="text-center mt-4">
            <a href="homepage.php" class="btn btn-secondary btn-back">← Back to Homepage</a>
        </div>
    </div>
</div>

</body>
</html>
