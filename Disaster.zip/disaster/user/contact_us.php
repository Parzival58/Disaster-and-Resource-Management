<?php
session_start();
include('config.php');

// Check if the user is logged in
$is_logged_in = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
$error = $success = "";

// Fetch the user's previous contact messages and replies
if ($is_logged_in) {
    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT id, problem_type, message, reply, admin_reply_date, submitted_at 
                            FROM contact_us 
                            WHERE user_id = ? 
                            ORDER BY submitted_at DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $messages = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // If the user is logged in, just ask for problem type and message
    if ($is_logged_in) {
        $problem_type = $_POST['problem_type'] ?? '';
        $message = $_POST['message'] ?? '';

        if (!empty($problem_type) && !empty($message)) {
            $user_id = $_SESSION['user_id'];  // Use the logged-in user's ID
            $stmt = $conn->prepare("INSERT INTO contact_us (user_id, problem_type, message, submitted_at) VALUES (?, ?, ?, NOW())");
            $stmt->bind_param("iss", $user_id, $problem_type, $message);

            if ($stmt->execute()) {
                $success = "✅ Your message has been sent successfully!";
            } else {
                $error = "❌ Failed to send your message. Please try again.";
            }
            $stmt->close();
        } else {
            $error = "❌ Please fill in all required fields.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .interaction-block {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #f9f9f9;
        }
        .user-message {
            border-left: 4px solid #007bff;
            padding-left: 10px;
            margin-bottom: 10px;
        }
        .admin-reply {
            border-left: 4px solid #28a745;
            padding-left: 10px;
        }
    </style>
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">📬 Contact Us</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Contact Us Form -->
    <form method="post">
        <?php if ($is_logged_in): ?>
            <!-- If logged in, ask for problem type and message -->
            <div class="mb-3">
                <label for="problem_type" class="form-label">Problem Type</label>
                <select name="problem_type" id="problem_type" class="form-select" required>
                    <option value="">Select Problem Type</option>
                    <option value="Technical Issue">Technical Issue</option>
                    <option value="Service Request">Service Request</option>
                    <option value="Feedback">Feedback</option>
                    <option value="Others">Others</option>
                </select>
            </div>
        <?php else: ?>
            <!-- If not logged in, ask for name, email, and message -->
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" id="name" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" id="email" required>
            </div>
        <?php endif; ?>

        <div class="mb-3">
            <label for="message" class="form-label">Message</label>
            <textarea name="message" class="form-control" id="message" rows="5" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

    <!-- Display User Messages and Admin Replies -->
    <?php if (!empty($messages)): ?>
        <h3 class="mt-4">Your Previous Messages</h3>
        <?php foreach ($messages as $msg): ?>
            <div class="interaction-block">
                <div class="user-message">
                    <p><strong>Message:</strong> <?= nl2br(htmlspecialchars($msg['message'])) ?></p>
                    <p><small class="text-muted">Submitted on: <?= date('d M Y, h:i A', strtotime($msg['submitted_at'])) ?></small></p>
                </div>

                <?php if ($msg['reply']): ?>
                    <div class="admin-reply">
                        <p><strong>Admin's Reply:</strong> <?= nl2br(htmlspecialchars($msg['reply'])) ?></p>
                        <p><small class="text-muted">Replied on: <?= date('d M Y, h:i A', strtotime($msg['admin_reply_date'])) ?></small></p>
                    </div>
                <?php else: ?>
                    <div class="admin-reply">
                        <p><strong>No reply yet from admin.</strong></p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="alert alert-info">📭 You haven't contacted us yet.</div>
    <?php endif; ?>

    <div class="mt-4">
        <a href="homepage.php" class="btn btn-secondary">← Back to Home</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
