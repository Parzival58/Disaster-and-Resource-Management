<?php
session_start();
include '../config.php';

// Ensure only logged-in users can access
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Fetch all disaster information ordered by most recent date
$sql = "SELECT * FROM disaster_information ORDER BY date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Disaster Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

    <div class="container mt-5">
        <h2>Disaster Information</h2>
        <a href="homepage.php" class="btn btn-secondary btn-sm mb-3">← Back to Home</a>

        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                        <p><strong>Type:</strong> <?= htmlspecialchars($row['type']) ?></p>
                        <p><strong>Severity:</strong> <?= htmlspecialchars($row['severity']) ?></p>
                        <p><?= nl2br(htmlspecialchars($row['description'])) ?></p>
                        <p><strong>Location:</strong> <?= htmlspecialchars($row['location']) ?></p>
                        <p><strong>Date:</strong> <?= htmlspecialchars($row['date']) ?></p>
        
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="alert alert-info">No disaster information found.</div>
        <?php endif; ?>
    </div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
