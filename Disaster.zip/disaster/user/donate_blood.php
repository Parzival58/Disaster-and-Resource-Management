<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user info
$user = $conn->query("SELECT blood_group, is_volunteer FROM users WHERE id = $user_id")->fetch_assoc();

if (!$user || $user['is_volunteer'] != 1) {
    die("Access denied. Only volunteers can donate blood.");
}

$blood_group = $user['blood_group'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Begin transaction
    $conn->begin_transaction();
    
    try {
        // Insert donation record into blood_donations table
        $stmt = $conn->prepare("INSERT INTO blood_donations (user_id, blood_group) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $blood_group);
        if ($stmt->execute()) {
            // Check if the blood group already exists in the shared blood_bank table
            $stmt = $conn->prepare("SELECT units_available FROM blood_bank WHERE blood_group = ?");
            $stmt->bind_param("s", $blood_group);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // If blood group exists, update the units_available
                $stmt = $conn->prepare("UPDATE blood_bank SET units_available = units_available + 1 WHERE blood_group = ?");
                $stmt->bind_param("s", $blood_group);
                $stmt->execute();
            } else {
                // If not, insert new blood group
                $stmt = $conn->prepare("INSERT INTO blood_bank (blood_group, units_available) VALUES (?, 1)");
                $stmt->bind_param("s", $blood_group);
                $stmt->execute();
            }

            // Commit the transaction
            $conn->commit();

            // Redirect with success message
            header("Location: homepage.php?success=blood_donated");
            exit();
        } else {
            throw new Exception("Failed to record donation.");
        }
    } catch (Exception $e) {
        // Rollback on failure
        $conn->rollback();
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donate Blood</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/js/all.min.js"></script>
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">🩸 Donate Blood</h2>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card shadow-sm p-4">
        <p>Your blood group: <strong><?= htmlspecialchars($blood_group) ?></strong></p>
        <p>Click the button below to confirm you have donated blood. Your contribution will be recorded and added to the blood bank.</p>

        <form method="post">
            <button type="submit" class="btn btn-danger btn-lg mt-2">
                <i class="fas fa-tint"></i> Confirm Blood Donation
            </button>
        </form>
    </div>

    <a href="homepage.php" class="btn btn-link mt-3">← Back to Homepage</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
