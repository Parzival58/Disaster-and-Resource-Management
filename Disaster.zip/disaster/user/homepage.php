<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];

$success_message = "";
if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case 'shelter_selected':
            $success_message = "✅ Shelter selection recorded successfully.";
            break;
        case 'sos_sent':
            $success_message = "✅ SOS request submitted successfully.";
            break;
        case 'checkin_success':
            $success_message = "✅ You have successfully checked into the shelter.";
            break;
        case 'checkout_success':
            $success_message = "✅ You have successfully checked out of the shelter.";
            break;
        case 'resource_taken':
            $success_message = "✅ Resource claimed successfully.";
            break;
        case 'resource_requested':
            $success_message = "✅ Resource request submitted.";
            break;
        case 'blood_donated':
            $success_message = "✅ Thank you for donating blood!";
            break;
        default:
            $success_message = htmlspecialchars($_GET['success']);
    }
}

$user_query = $conn->query("SELECT is_volunteer FROM users WHERE id = $user_id");
$user_data = $user_query->fetch_assoc();
$is_volunteer = isset($user_data['is_volunteer']) && $user_data['is_volunteer'] == 1;

$disasters = $conn->query("SELECT * FROM disaster_information ORDER BY date DESC LIMIT 2");
$messages = $conn->query("
    SELECT pm.*, d.name AS disaster_name, d.severity
    FROM public_message pm
    JOIN disaster_information d ON pm.disasters_id = d.id
    ORDER BY pm.date_posted DESC
    LIMIT 2
");
$shelters = $conn->query("SELECT * FROM shelter_information ORDER BY name ASC");

$checkin_query = $conn->query("SELECT * FROM shelter_checkins sc JOIN shelter_information si ON sc.shelter_id = si.id WHERE user_id = $user_id AND checkout_time IS NULL");
$current_checkin = $checkin_query->fetch_assoc();

$resources = $conn->query("
    SELECT r.*, s.name AS shelter_name
    FROM resources r
    JOIN shelter_information s ON r.shelter_id = s.id
    WHERE r.quantity > 0
    ORDER BY r.name ASC
    LIMIT 5
");

// Blood Bank: View Available Blood Donations
$blood_bank = $conn->query("SELECT * FROM blood_bank ORDER BY blood_group ASC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Homepage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { font-family: 'Arial', sans-serif; background-color: #f4f4f4; }
        .section-title { font-size: 1.6rem; font-weight: 600; margin-bottom: 0.8rem; }
        .btn-service {
            width: 100%; padding: 12px; font-size: 1.1rem; border-radius: 8px; margin-bottom: 15px;
            display: flex; align-items: center; justify-content: center; gap: 10px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn-service:hover { transform: scale(1.02); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1); }
        .content-box { background-color: #fff; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .grid-row { display: flex; flex-wrap: wrap; gap: 20px; }
        .grid-col-left, .grid-col-right { flex: 1 1 calc(50% - 10px); min-width: 280px; }
        .alert-success { margin-bottom: 20px; }
        .card-body p { font-size: 0.9rem; line-height: 1.5; }
    </style>
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-4">
    <h2>Welcome, <?= htmlspecialchars($username) ?><?= $is_volunteer ? ' (Volunteer)' : '' ?>!</h2>

    <?php if ($success_message): ?>
        <div class="alert alert-success"><?= $success_message ?></div>
    <?php endif; ?>

    <div class="grid-row">
        <!-- Left Column -->
        <div class="grid-col-left">

            <!-- Emergency Services -->
            <div class="content-box">
                <h3 class="section-title">🚨 Emergency Services</h3>
                <a href="user_fire_view.php" class="btn btn-danger btn-service">
                    <i class="fas fa-fire-extinguisher"></i> Fire Services
                </a>
                <a href="user_ambulance_view.php" class="btn btn-warning btn-service">
                    <i class="fas fa-ambulance"></i> Ambulances
                </a>
                <a href="user_police_view.php" class="btn btn-primary btn-service">
                    <i class="fas fa-shield-alt"></i> Police Stations
                </a>
                <a href="user_hospital_view.php" class="btn btn-success btn-service">
                    <i class="fas fa-hospital"></i> Hospitals
                </a>
            </div>

            <!-- Shelter Check-in -->
            <div class="content-box">
                <h3 class="section-title">🏨 Shelter Check-In</h3>
                <?php if ($current_checkin): ?>
                    <p>You are currently checked in at <strong><?= htmlspecialchars($current_checkin['name']) ?></strong> since <strong><?= htmlspecialchars($current_checkin['checkin_time']) ?></strong>.</p>
                    <a href="shelter_checkout.php" class="btn btn-outline-danger">Check Out</a>
                <?php else: ?>
                    <form action="shelter_checkin.php" method="post">
                        <button type="submit" class="btn btn-primary">Check In</button>
                    </form>
                <?php endif; ?>
            </div>

            <!-- Blood Donation (only for volunteers) -->
            <?php if ($is_volunteer): ?>
            <div class="content-box">
                <h3 class="section-title">🩸 Donate Blood</h3>
                <p>Help save lives during this crisis. Record your blood donation.</p>
                <a href="donate_blood.php" class="btn btn-danger btn-service">
                    <i class="fas fa-tint"></i> Donate Blood
                </a>
            </div>
            <?php endif; ?>

            <!-- Resource Section -->
            <div class="content-box">
                <h3 class="section-title">📦 Available Resources</h3>
                <?php if ($resources->num_rows > 0): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Quantity</th>
                                <th>Shelter</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while ($r = $resources->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($r['name']) ?></td>
                                <td><?= htmlspecialchars($r['type']) ?></td>
                                <td><?= htmlspecialchars($r['quantity']) ?></td>
                                <td><?= htmlspecialchars($r['shelter_name']) ?></td>
                                <td>
                                    <?php if ($r['quantity'] > 0): ?>
                                        <form action="take_resource.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="resource_id" value="<?= $r['id'] ?>">
                                            <button class="btn btn-sm btn-outline-success" onclick="return confirm('Confirm claim?')">Claim</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted">Unavailable</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-between">
                        <a href="resources.php" class="btn btn-outline-primary">View All Resources</a>
                        <?php if ($current_checkin): ?>
                            <a href="request_resource.php" class="btn btn-outline-warning">Request Resource</a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <p>No resources available at this time.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Right Column -->
        <div class="grid-col-right">
            <div class="content-box">
                <h3 class="section-title">📢 Latest Public Messages</h3>
                <?php if ($messages->num_rows > 0): ?>
                    <?php while ($row = $messages->fetch_assoc()): ?>
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($row['disaster_name']) ?></h5>
                                <p class="badge bg-danger">Severity: <?= htmlspecialchars($row['severity']) ?></p>
                                <p class="mt-2"><?= nl2br(htmlspecialchars($row['message'])) ?></p>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <a href="public_messages.php" class="btn btn-outline-primary mt-2">View More</a>
                <?php else: ?>
                    <p>No public messages available.</p>
                <?php endif; ?>
            </div>

            <!-- Recent Disasters -->
            <div class="content-box mt-4">
                <h3 class="section-title">🧬 Recent Disasters</h3>
                <?php if ($disasters->num_rows > 0): ?>
                    <div class="row">
                        <?php while ($row = $disasters->fetch_assoc()): ?>
                            <div class="col-6 mb-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                                        <p><strong>Type:</strong> <?= htmlspecialchars($row['type']) ?></p>
                                        <p><strong>Severity:</strong> <?= htmlspecialchars($row['severity']) ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <a href="disaster_information.php" class="btn btn-outline-primary">View More</a>
                <?php else: ?>
                    <p>No recent disaster information.</p>
                <?php endif; ?>
            </div>

            <!-- Blood Bank -->
            <div class="content-box mt-4">
                <h3 class="section-title">🩸 Blood Bank</h3>
                <?php if ($blood_bank->num_rows > 0): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Blood Group</th>
                                <th>Units Available</th>
                                <th>Last Updated</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $blood_bank->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['blood_group']) ?></td>
                                    <td><?= htmlspecialchars($row['units_available']) ?></td>
                                    <td><?= htmlspecialchars($row['last_updated']) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <a href="view_donors.php" class="btn btn-outline-primary mt-2">View Blood Donors</a>
                <?php else: ?>
                    <p>No blood available at this time.</p>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <p class="mt-4"><a href="logout.php">Logout</a></p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
