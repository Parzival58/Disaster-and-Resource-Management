<?php
include('config.php');

$current_page = basename($_SERVER['PHP_SELF']);

// Default: user is not a volunteer
$is_volunteer = 0;

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $query = $conn->prepare("SELECT is_volunteer FROM users WHERE id = ?");
    $query->bind_param("i", $user_id);
    $query->execute();
    $result = $query->get_result();
    if ($result && $row = $result->fetch_assoc()) {
        $is_volunteer = $row['is_volunteer'];
    }
}
?>

<!-- Bootstrap Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-3">
  <div class="container-fluid">
    <!-- Brand -->
    <a class="navbar-brand fw-bold" href="homepage.php">
      <i class="fas fa-globe-americas me-2"></i> Disaster & Resource Management
    </a>

    <!-- Mobile Toggle Button -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
      aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Navbar Content -->
    <div class="collapse navbar-collapse" id="navbarContent">
      <!-- Centered Links -->
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
        <li class="nav-item mx-2">
          <a class="nav-link <?= $current_page == 'homepage.php' ? 'active' : '' ?>" href="homepage.php">
            <i class="fas fa-home me-1"></i> Home
          </a>
        </li>
        <li class="nav-item mx-2">
          <a class="nav-link <?= $current_page == 'sos_add.php' ? 'active' : '' ?>" href="sos_add.php">
            <i class="fas fa-bell me-1"></i> Request SOS
          </a>
        </li>
        <li class="nav-item mx-2">
          <a class="nav-link <?= $current_page == 'disaster_information.php' ? 'active' : '' ?>" href="disaster_information.php">
            <i class="fas fa-exclamation-triangle me-1"></i> Disaster Info
          </a>
        </li>
        <li class="nav-item mx-2">
          <a class="nav-link <?= $current_page == 'public_messages.php' ? 'active' : '' ?>" href="public_messages.php">
            <i class="fas fa-comments me-1"></i> Public Messages
          </a>
        </li>
        <li class="nav-item mx-2">
          <a class="nav-link <?= $current_page == 'contact_us.php' ? 'active' : '' ?>" href="contact_us.php">
            <i class="fas fa-envelope me-1"></i> Contact Us
          </a>
        </li>

        <?php if (isset($_SESSION['user_id']) && !$is_volunteer): ?>
        <li class="nav-item mx-2">
          <a class="nav-link btn btn-warning text-dark px-3 py-1" href="apply_volunteer.php">
            <i class="fas fa-hands-helping me-1"></i> Apply for Volunteer
          </a>
        </li>
        <?php endif; ?>
      </ul>

      <!-- Right Side: Profile and Logout -->
      <div class="d-flex">

        <a class="btn btn-outline-danger" href="../index.php">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </div>
    </div>
  </div>
</nav>
