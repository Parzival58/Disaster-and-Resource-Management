<?php
include 'config.php';

// Get messages with related disaster and admin name
$sql = "SELECT pm.*, d.name AS disaster_name, u.name AS admin_name
        FROM public_message pm
        LEFT JOIN disaster_information d ON pm.disasters_id = d.id
        LEFT JOIN users u ON pm.posted_by = u.id
        ORDER BY pm.date_posted DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Public Disaster Messages</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">📢 Latest Disaster Announcements</h2>

    <?php if ($result->num_rows === 0): ?>
        <div class="alert alert-info">No messages yet.</div>
    <?php else: ?>
        <div class="row">
            <?php $count = 0; ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($row['disaster_name']) ?></h5>
                            <p class="card-text">
                                <strong>Evacuation Priority:</strong> <?= htmlspecialchars($row['evacuation_priority']) ?><br>
                                <strong>Message:</strong><br>
                                <?= nl2br(htmlspecialchars($row['message'])) ?>
                            </p>
                        </div>
                        <div class="card-footer text-muted small">
                            Posted on <?= htmlspecialchars($row['date_posted']) ?> by <?= htmlspecialchars($row['admin_name']) ?>
                        </div>
                    </div>
                </div>
                <?php $count++; ?>
                <?php if ($count % 3 == 0): ?>
                    </div><div class="row">
                <?php endif; ?>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
