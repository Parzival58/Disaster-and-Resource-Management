<?php
include 'config.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data
    $name = isset($_POST['resource_name']) ? htmlspecialchars($_POST['resource_name']) : '';
    $type = isset($_POST['type']) ? htmlspecialchars($_POST['type']) : '';
    $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    
    // Assuming that user_id should be fetched from session
    session_start(); // Start session to retrieve user info
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php"); // Redirect to login if not logged in
        exit();
    }

    $user_id = $_SESSION['user_id']; // Get user_id from session

    // Fetch the shelter_id where the user is checked in
    $shelter_query = $conn->prepare("SELECT shelter_id FROM shelter_checkins WHERE user_id = ? AND checkout_time IS NULL");
    $shelter_query->bind_param("i", $user_id);
    $shelter_query->execute();
    $shelter_query->store_result();

    if ($shelter_query->num_rows === 0) {
        $message = "❌ You are not currently checked into any shelter.";
    } else {
        $shelter_query->bind_result($shelter_id);
        $shelter_query->fetch(); // Get the shelter_id
        
        // Prepare and execute the query to insert the resource request
        $stmt = $conn->prepare("INSERT INTO resource_request (resource_name, type, requested_quantity, requested_by_user_id, shelter_id)
                                VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiii", $name, $type, $qty, $user_id, $shelter_id);

        if ($stmt->execute()) {
            $message = "✅ Request submitted successfully.";
        } else {
            $message = "❌ Failed to submit request.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Request Resource</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>📝 Request New Resource</h2>

    <?php if ($message): ?>
        <div class="alert alert-info"><?= $message ?></div>
    <?php endif; ?>

    <form method="POST" class="row g-3">
        <div class="col-md-6">
            <label for="resource_name" class="form-label">Resource Name</label>
            <input type="text" name="resource_name" class="form-control" value="<?= isset($_POST['resource_name']) ? htmlspecialchars($_POST['resource_name']) : '' ?>" required>
        </div>
        <div class="col-md-6">
            <label for="type" class="form-label">Type</label>
            <input type="text" name="type" class="form-control" value="<?= isset($_POST['type']) ? htmlspecialchars($_POST['type']) : '' ?>" required>
        </div>
        <div class="col-md-4">
            <label for="quantity" class="form-label">Quantity</label>
            <input type="number" name="quantity" class="form-control" value="<?= isset($_POST['quantity']) ? $_POST['quantity'] : '' ?>" required>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Submit Request</button>
        </div>
    </form>

    <a href="homepage.php" class="btn btn-outline-primary mt-3">Back to Home</a>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
