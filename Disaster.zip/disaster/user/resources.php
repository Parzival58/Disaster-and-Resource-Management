<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Pagination settings
$limit = 10; // Number of resources per page
$page = isset($_GET['page']) ? intval($_GET['page']) : 1; // Current page (default to 1)

$offset = ($page - 1) * $limit; // Calculate offset for SQL query

// Fetch resources with pagination
$resources_query = $conn->prepare("SELECT r.*, s.name AS shelter_name 
                                   FROM resources r 
                                   JOIN shelter_information s ON r.shelter_id = s.id
                                   WHERE r.quantity > 0 
                                   ORDER BY r.name ASC 
                                   LIMIT ?, ?");
$resources_query->bind_param("ii", $offset, $limit);
$resources_query->execute();
$resources_result = $resources_query->get_result();

// Get total number of resources for pagination
$total_query = $conn->query("SELECT COUNT(*) AS total FROM resources WHERE quantity > 0");
$total_resources = $total_query->fetch_assoc()['total'];
$total_pages = ceil($total_resources / $limit); // Calculate total pages

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Available Resources</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('navbar.php'); ?>

<div class="container mt-4">
    <h2>📦 Available Resources</h2>

    <?php if ($resources_result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Quantity</th>
                    <th>Shelter</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($r = $resources_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['name']) ?></td>
                        <td><?= htmlspecialchars($r['type']) ?></td>
                        <td><?= htmlspecialchars($r['quantity']) ?></td>
                        <td><?= htmlspecialchars($r['shelter_name']) ?></td>
                        <td>
                            <form action="take_resource.php" method="POST" style="display:inline;">
                                <input type="hidden" name="resource_id" value="<?= $r['id'] ?>">
                                <button class="btn btn-sm btn-outline-success" onclick="return confirm('Confirm claim?')">Claim</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No resources available at this time.</p>
    <?php endif; ?>

    <!-- Pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="resources.php?page=<?= $page - 1 ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                    <a class="page-link" href="resources.php?page=<?= $i ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="resources.php?page=<?= $page + 1 ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

    <a href="homepage.php" class="btn btn-outline-primary mt-3">Back to Home</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
