<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    die("Access denied. Please log in.");
}

$user_id = $_SESSION['user_id'];

// Handle check-in
if (isset($_POST['checkin_id'])) {
    $shelter_id = (int) $_POST['checkin_id'];

    // Check if already checked in
    $check = $conn->prepare("SELECT * FROM shelter_checkins WHERE user_id = ? AND checkout_time IS NULL");
    $check->bind_param("i", $user_id);
    $check->execute();
    $result = $check->get_result();
    if ($result->num_rows == 0) {
        $stmt = $conn->prepare("INSERT INTO shelter_checkins (user_id, shelter_id, checkin_time) VALUES (?, ?, NOW())");
        $stmt->bind_param("ii", $user_id, $shelter_id);
        $stmt->execute();
        $conn->query("UPDATE shelter_information SET current_occupancy = current_occupancy + 1 WHERE id = $shelter_id");
        $stmt->close();
    }
    $check->close();
}

// Handle check-out
if (isset($_POST['checkout'])) {
    $stmt = $conn->prepare("SELECT shelter_id FROM shelter_checkins WHERE user_id = ? AND checkout_time IS NULL");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $shelter_id = $row['shelter_id'];
        $conn->query("UPDATE shelter_checkins SET checkout_time = NOW() WHERE user_id = $user_id AND checkout_time IS NULL");
        $conn->query("UPDATE shelter_information SET current_occupancy = current_occupancy - 1 WHERE id = $shelter_id");
    }
    $stmt->close();
}

// Get current check-in status
$checkin_status = $conn->prepare("SELECT s.name, s.location, sc.checkin_time 
                                  FROM shelter_checkins sc
                                  JOIN shelter_information s ON sc.shelter_id = s.id
                                  WHERE sc.user_id = ? AND sc.checkout_time IS NULL");
$checkin_status->bind_param("i", $user_id);
$checkin_status->execute();
$status_result = $checkin_status->get_result();
$current_checkin = $status_result->fetch_assoc();
$checkin_status->close();

// Fetch all shelters
$shelters = $conn->query("SELECT * FROM shelter_information");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shelter Check-In</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>🏠 Shelter Check-In</h2>

    <!-- Back to Home Button -->
    <a href="homepage.php" class="btn btn-secondary mb-3">Back to Home</a>

    <?php if ($current_checkin): ?>
        <div class="alert alert-info">
            ✅ You are currently checked into <strong><?= htmlspecialchars($current_checkin['name']) ?></strong>
            at <?= htmlspecialchars($current_checkin['location']) ?> since <?= $current_checkin['checkin_time'] ?>.
            <form method="POST" class="mt-2">
                <button name="checkout" class="btn btn-danger">Check Out</button>
            </form>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Shelter Name</th>
                <th>Location</th>
                <th>Capacity</th>
                <th>Current Occupancy</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $i = 1; while ($row = $shelters->fetch_assoc()): ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['location']) ?></td>
                <td><?= $row['capacity'] ?></td>
                <td><?= $row['current_occupancy'] ?></td>
                <td>
                    <?php if (!$current_checkin): ?>
                        <form method="POST">
                            <input type="hidden" name="checkin_id" value="<?= $row['id'] ?>">
                            <button class="btn btn-primary">Check In</button>
                        </form>
                    <?php else: ?>
                        <span class="badge bg-secondary">Already Checked In</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
