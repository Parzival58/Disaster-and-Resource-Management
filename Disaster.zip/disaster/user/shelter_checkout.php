<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Find the active check-in for this user
$query = $conn->prepare("SELECT id FROM shelter_checkins WHERE user_id = ? AND checkout_time IS NULL LIMIT 1");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();

if ($result->num_rows === 0) {
    // No active check-in found
    header("Location: homepage.php?success=No active shelter check-in found.");
    exit();
}

// Update the checkout time to now
$row = $result->fetch_assoc();
$checkin_id = $row['id'];
$update = $conn->prepare("UPDATE shelter_checkins SET checkout_time = NOW() WHERE id = ?");
$update->bind_param("i", $checkin_id);
$update->execute();

header("Location: homepage.php?success=checkout_success");
exit();
?>
