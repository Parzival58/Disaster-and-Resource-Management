<?php
include('config.php');

// Initialize error message
$phone_error = '';

// Initialize variables to retain the entered values
$name = $phone = $location = $reason = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize user inputs
    $name = $conn->real_escape_string($_POST['NAME']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $location = $conn->real_escape_string($_POST['location']);
    $reason = $conn->real_escape_string($_POST['Reason']);
    
    // Server-side validation for phone number format (must be 10 digits)
    if (!preg_match('/^[0-9]{11}$/', $phone)) {
        $phone_error = "Invalid phone number format. Please enter a 11-digit phone number.";
    } else {
        // Get user IP address and timestamp for emergency services
        $user_ip = $_SERVER['REMOTE_ADDR'];
        $created_at = date('Y-m-d H:i:s');
        
        // Insert SOS request into the database
        $query = "INSERT INTO sos (NAME, phone, location, Reason, created_at, user_ip) 
                  VALUES ('$name', '$phone', '$location', '$reason', '$created_at', '$user_ip')";
        
        if ($conn->query($query) === TRUE) {
            // Redirect to the user homepage with a success message
            header("Location: homepage.php?success=SOS request submitted successfully.");
            exit();
        } else {
            echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send SOS Request</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include('navbar.php'); ?> <!-- Including the navbar -->

<div class="container mt-5">
    <h2 class="text-center">Send SOS Request</h2>
    
    <!-- Form to submit SOS request -->
    <form method="POST" class="shadow p-4 rounded border">
        <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" class="form-control" name="NAME" value="<?= htmlspecialchars($name) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone Number</label>
            <input type="text" class="form-control" name="phone" value="<?= htmlspecialchars($phone) ?>" required>
            <small class="form-text text-muted">Please enter a valid 11-digit phone number.</small>
            <?php if (!empty($phone_error)): ?>
                <div class="text-danger mt-2"><?= $phone_error; ?></div>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" class="form-control" name="location" value="<?= htmlspecialchars($location) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Reason</label>
            <textarea class="form-control" name="Reason" required><?= htmlspecialchars($reason) ?></textarea>
        </div>
        <button type="submit" class="btn btn-warning w-100">Send SOS</button>
    </form>
</div>

<!-- Bootstrap JS and Dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
