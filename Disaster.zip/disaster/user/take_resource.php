<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$resource_id = isset($_POST['resource_id']) ? intval($_POST['resource_id']) : 0;

// Validate resource ID
if ($resource_id > 0) {
    // Update resource quantity (only if quantity > 0)
    $stmt = $conn->prepare("UPDATE resources SET quantity = quantity - 1 WHERE id = ? AND quantity > 0");
    $stmt->bind_param("i", $resource_id);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        // Redirect with success message
        header("Location: resources.php?success=resource_taken");
    } else {
        // If no quantity was updated, resource was unavailable
        header("Location: resources.php?error=resource_unavailable");
    }
} else {
    // Invalid resource ID
    header("Location: resources.php?error=invalid_resource");
}
exit();