<?php
include 'config.php';  // Ensure this path is correct for your database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ambulances</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- Navbar (Same as the one used in other pages) -->
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>🚑 Ambulances</h2>

    <!-- Search Form -->
    <form method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by driver or location" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <!-- Ambulance Table -->
    <table class="table table-bordered table-striped">
        <thead class="table-light">
            <tr>
                <th>Serial</th>
                <th>Driver</th>
                <th>Phone Number</th>
                <th>Registration</th>
                <th>Location</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = 1;
            $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
            $query = "SELECT * FROM ambulance";
            if ($search) {
                $query .= " WHERE driver LIKE '%$search%' OR location LIKE '%$search%'";
            }

            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$serial}</td>
                            <td>" . htmlspecialchars($row['driver']) . "</td>
                            <td>" . htmlspecialchars($row['driver_phone_number']) . "</td>
                            <td>" . htmlspecialchars($row['registration_number']) . "</td>
                            <td>" . htmlspecialchars($row['location']) . "</td>
                          </tr>";
                    $serial++;
                }
            } else {
                echo "<tr><td colspan='5' class='text-center'>No ambulances found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

</div>

<!-- Bootstrap JS (Including Popper.js) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
