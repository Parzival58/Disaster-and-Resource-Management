<?php
include 'config.php';  // Ensure this path is correct for your database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospitals</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- Navbar (Assuming this is the same as the one used on other pages) -->
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>🏥 Hospitals</h2>

    <!-- Search Form -->
    <form method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by hospital name or location" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <!-- Hospitals Table -->
    <table class="table table-bordered table-striped">
        <thead class="table-light">
            <tr>
                <th>Serial</th>
                <th>Hospital Name</th>
                <th>Phone</th>
                <th>Doctors</th>
                <th>Nurses</th>
                <th>Blood Units</th>
                <th>Location</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = 1;
            $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
            $query = "SELECT * FROM hospital";
            if ($search) {
                $query .= " WHERE hospital_name LIKE '%$search%' OR location LIKE '%$search%'";
            }

            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$serial}</td>
                            <td>" . htmlspecialchars($row['hospital_name']) . "</td>
                            <td>" . htmlspecialchars($row['phone_number']) . "</td>
                            <td>" . htmlspecialchars($row['doctors']) . "</td>
                            <td>" . htmlspecialchars($row['nurses']) . "</td>
                            <td>" . htmlspecialchars($row['stored_blood']) . "</td>
                            <td>" . htmlspecialchars($row['location']) . "</td>
                          </tr>";
                    $serial++;
                }
            } else {
                echo "<tr><td colspan='7' class='text-center'>No hospitals found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

</div>

<!-- Bootstrap JS (Including Popper.js) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
