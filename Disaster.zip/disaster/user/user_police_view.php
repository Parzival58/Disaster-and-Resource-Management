<?php
include 'config.php';  // Ensure this is the correct path
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Police Stations</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>🚓 Police Stations</h2>

    <!-- Search Form -->
    <form method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by station name or location" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <!-- Police Stations Table -->
    <table class="table table-bordered table-striped">
        <thead class="table-light">
            <tr>
                <th>Serial</th>
                <th>Station Name</th>
                <th>Contact Number</th>
                <th>Location</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = 1;
            $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
            $query = "SELECT * FROM police";
            if ($search) {
                $query .= " WHERE station_name LIKE '%$search%' OR location LIKE '%$search%'";
            }

            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$serial}</td>
                            <td>" . htmlspecialchars($row['station_name']) . "</td>
                            <td>" . htmlspecialchars($row['contact_number']) . "</td>
                            <td>" . htmlspecialchars($row['location']) . "</td>
                          </tr>";
                    $serial++;
                }
            } else {
                echo "<tr><td colspan='4' class='text-center'>No police stations found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

</div>

<!-- Bootstrap 5 JS Bundle (with Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
