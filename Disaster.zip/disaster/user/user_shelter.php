<?php
include 'config.php';  // Ensure this path is correct
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shelters</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Optional: Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link rel="stylesheet" href="../css/style.css">
    <style>
        .availability-full {
            color: #fff;
            background-color: #dc3545;
        }

        .availability-available {
            color: #fff;
            background-color: #28a745;
        }

        .progress-bar {
            font-weight: bold;
        }

        .shelter-card {
            border-radius: 12px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            transition: transform 0.2s ease;
        }

        .shelter-card:hover {
            transform: scale(1.01);
        }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4"><i class="fas fa-house-user"></i> Available Shelters</h2>

    <!-- Search & Filter -->
    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-6">
            <input type="text" name="search" class="form-control" placeholder="Search by name or location"
                   value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        </div>
        <div class="col-md-3">
            <select name="availability" class="form-select">
                <option value="">All Shelters</option>
                <option value="available" <?= (isset($_GET['availability']) && $_GET['availability'] === 'available') ? 'selected' : '' ?>>Only Available</option>
            </select>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i> Search</button>
        </div>
    </form>

    <?php
    $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
    $availability_filter = isset($_GET['availability']) ? $_GET['availability'] : '';

    $query = "SELECT * FROM shelter_information";
    $conditions = [];

    if ($search !== '') {
        $conditions[] = "(name LIKE '%$search%' OR location LIKE '%$search%')";
    }

    if ($availability_filter === 'available') {
        $conditions[] = "(capacity > current_occupancy)";
    }

    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }

    $query .= " ORDER BY name ASC";

    $result = $conn->query($query);
    ?>

    <?php if ($result->num_rows > 0): ?>
        <div class="row">
            <?php while ($row = $result->fetch_assoc()): 
                $name = htmlspecialchars($row['name']);
                $location = htmlspecialchars($row['location']);
                $capacity = (int)$row['capacity'];
                $occupancy = (int)$row['current_occupancy'];
                $available = $capacity - $occupancy;
                $percent = ($capacity > 0) ? round(($occupancy / $capacity) * 100) : 0;

                $availability_class = ($available > 0) ? 'availability-available' : 'availability-full';
            ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card shelter-card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?= $name ?></h5>
                            <p class="card-text"><strong>Location:</strong> <?= $location ?></p>
                            <p class="card-text"><strong>Capacity:</strong> <?= $capacity ?></p>
                            <p class="card-text"><strong>Current Occupancy:</strong> <?= $occupancy ?></p>

                            <div class="progress mb-2">
                                <div class="progress-bar <?= $availability_class ?>" 
                                     role="progressbar" 
                                     style="width: <?= $percent ?>%;" 
                                     aria-valuenow="<?= $percent ?>" 
                                     aria-valuemin="0" 
                                     aria-valuemax="100">
                                    <?= $percent ?>%
                                </div>
                            </div>

                            <?php if ($available > 0): ?>
                                <span class="badge bg-success"><i class="fas fa-check-circle"></i> Beds Available</span>
                            <?php else: ?>
                                <span class="badge bg-danger"><i class="fas fa-times-circle"></i> Full</span>
                            <?php endif; ?>
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="request_shelter.php?shelter_id=<?= $row['id'] ?>" class="btn btn-outline-primary w-100">
                                <i class="fas fa-hand-holding-heart"></i> Request Shelter
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">No shelters found.</div>
    <?php endif; ?>
</div>

<!-- Bootstrap & FontAwesome JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>

</body>
</html>
