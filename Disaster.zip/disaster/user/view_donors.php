<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch volunteers and their **latest** blood donation history
$volunteers = $conn->query("
    SELECT u.name, u.blood_group, u.phone, u.location,
           (SELECT MAX(donation_date) FROM blood_donations WHERE user_id = u.id) AS latest_donation
    FROM users u
    WHERE u.is_volunteer = 1
    ORDER BY u.blood_group ASC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Available Blood Donors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include('navbar.php'); ?>

<div class="container mt-5">
    <h2 class="mb-4">🩸 Available Blood Donors</h2>

    <div class="card mb-5">
        <div class="card-header bg-primary text-white">Volunteer Donors</div>
        <div class="card-body">
            <?php if ($volunteers->num_rows > 0): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Blood Group</th>
                            <th>Phone</th>
                            <th>Last Donation Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($v = $volunteers->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($v['name']) ?></td>
                                <td><?= htmlspecialchars($v['blood_group']) ?></td>
                                <td><?= htmlspecialchars($v['phone']) ?></td>
                              
                                <td><?= $v['latest_donation'] ? htmlspecialchars($v['latest_donation']) : 'No donation yet' ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No volunteers available currently.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-success text-white">Blood Bank Inventory</div>
        <div class="card-body">
            <?php
            // Fetch blood availability, sorted by blood group
            $blood_bank = $conn->query("SELECT blood_group, units_available FROM blood_bank ORDER BY blood_group ASC");
            if ($blood_bank->num_rows > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Blood Group</th>
                            <th>Units Available</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($b = $blood_bank->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($b['blood_group']) ?></td>
                                <td><?= htmlspecialchars($b['units_available']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No blood data found in the blood bank.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
