<?php
session_start();
include('db.php');

// Redirect if not logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'user') {
    header("Location: login.php");
    exit();
}

// Ensure user has selected their current role (victim or volunteer)
if (!isset($_SESSION['current_role'])) {
    header("Location: select_role.php");
    exit();
}

$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$user_type = $_SESSION['current_role']; // Get victim/volunteer from session
$name = strtoupper($user['name']); // Display name in uppercase

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include 'header.php'; ?>
<div class="container mt-5">
    <div class="card shadow p-4">
    <h3 class="text-center mb-4">User Dashboard</h3>
        <h3 class="text-center mb-4">Welcome, <?= $name ?>!</h3>

        <div class="alert alert-info text-center">
            You are logged in as <strong><?= ucfirst($user_type) ?></strong>.
        </div>

        <div class="row g-3">
            <?php if ($user_type == 'volunteer'): ?>
                <div class="col-md-4">
                    <a href="view_volunteer_info.php" class="btn btn-primary w-100">View / Edit My Volunteer Info</a>
                </div>
                <div class="col-md-4">
                    <a href="view_shelters.php" class="btn btn-success w-100">Find Nearby Shelters</a>
                </div>
                <div class="col-md-4">
                    <a href="volunteer_opportunities.php" class="btn btn-warning w-100">View Volunteer Opportunities</a>
                </div>

            <?php elseif ($user_type == 'victim'): ?>
                <div class="col-md-4">
                    <a href="view_victim_info.php" class="btn btn-danger w-100">View / Edit My Needs</a>
                </div>
                <div class="col-md-4">
                    <a href="request_aid.php" class="btn btn-warning w-100">Request Aid</a>
                </div>
                <div class="col-md-4">
                    <a href="view_shelters.php" class="btn btn-success w-100">Find Nearby Shelters</a>
                </div>
            <?php endif; ?>
        </div>

        <div class="text-center mt-4">
            <a href="logout.php" class="btn btn-secondary">Logout</a>
        </div>
    </div>
</div>

</body>
</html>
