<?php
session_start();
include('db.php');

// Check admin access
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch all disasters
$stmt = $conn->prepare("SELECT * FROM disasters");
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Disasters</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function confirmDelete(name, url) {
            if (confirm("Are you sure you want to delete disaster '" + name + "' from the database?")) {
                window.location.href = url;
            }
        }
    </script>
</head>
<body class="bg-light">
<?php include 'header.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Manage Disasters</h2>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            Disaster <strong><?= htmlspecialchars($_GET['success']) ?></strong> added successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php elseif (isset($_GET['updated'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            Disaster <strong><?= htmlspecialchars($_GET['updated']) ?></strong> updated successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php elseif (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            Disaster <strong><?= htmlspecialchars($_GET['deleted']) ?></strong> deleted successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Place</th>
                <th>Severity</th>
                <th>Year</th>
                <th>Duration (days)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($disaster = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $disaster['id'] ?></td>
                    <td><?= htmlspecialchars($disaster['name']) ?></td>
                    <td><?= htmlspecialchars($disaster['place']) ?></td>
                    <td><?= htmlspecialchars($disaster['severity']) ?></td>
                    <td><?= htmlspecialchars($disaster['year']) ?></td>
                    <td><?= htmlspecialchars($disaster['duration']) ?></td>
                    <td>
                        <a href="edit_disaster.php?id=<?= $disaster['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        <button onclick="confirmDelete('<?= htmlspecialchars(addslashes($disaster['name'])) ?>', 'delete_disaster.php?id=<?= $disaster['id'] ?>&name=<?= urlencode($disaster['name']) ?>')" class="btn btn-sm btn-danger">Delete</button>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <div class="text-center mt-3">
        <a href="add_disaster.php" class="btn btn-primary btn-sm">Add New Disaster</a>
        <a href="admin_dashboard.php" class="btn btn-secondary btn-sm">Back to Dashboard</a>
    </div>
</div>

</body>
</html>
