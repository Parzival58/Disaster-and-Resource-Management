<?php
session_start();
include('db.php');

// Check admin access
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch all users
$result = $conn->query("SELECT * FROM users");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Manage Users</h2>

    <!-- Success/Error Messages -->
    <?php if (isset($_GET['success']) && $_GET['success'] == 'update'): ?>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            User information updated successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            User deleted successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['error']) && $_GET['error'] == 'unauthorized_edit'): ?>
        <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
            You are not authorized to edit other admin's data.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['error']) && $_GET['error'] == 'unauthorized_delete'): ?>
        <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
            You are not authorized to delete other admin's account.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <table class="table table-bordered table-hover">
        <thead class="table-dark text-center">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Username</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Language</th>
                <th>Blood Group</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php while ($user = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $user['id'] ?></td>
                    <td><?= htmlspecialchars($user['name']) ?></td>
                    <td><?= htmlspecialchars($user['username']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td><?= $user['phone_number'] ?></td>
                    <td><?= htmlspecialchars($user['language']) ?></td>
                    <td><?= htmlspecialchars($user['blood_group']) ?></td>
                    <td><?= $user['role'] ?></td>
                    <td>
                        <?php
                        // Check if the current user is trying to edit/delete their own account
                        $isOwnAccount = ($user['username'] == $_SESSION['username']);
                        // Check if the user is an admin and is not the current logged-in admin
                        $isOtherAdmin = ($user['role'] == 'admin' && $user['username'] != $_SESSION['username']);
                        ?>

                        <?php if (!$isOwnAccount && !$isOtherAdmin): ?>
                            <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="delete_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-danger" 
   onclick="return confirm('Are You Sure You Want to Delete User <?= htmlspecialchars($user['username']) ?> From The Database?')">Delete</a>
                        <?php elseif ($isOwnAccount): ?>
                            <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <!-- No delete button for own account -->
                        <?php else: ?>
                            <span class="text-muted">Restricted</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <div class="text-center mt-3">
        <a href="admin_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
